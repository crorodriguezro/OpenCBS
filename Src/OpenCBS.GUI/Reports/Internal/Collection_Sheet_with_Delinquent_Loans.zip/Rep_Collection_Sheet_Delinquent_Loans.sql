CREATE PROCEDURE dbo.Rep_Collection_Sheet_Delinquent_Loans 
@user_id  INT
, @beginDate DATETIME
, @disbursed_in INT
, @display_in INT
, @subordinate_id INT
, @branch_id INT
AS BEGIN
	-- Create temporary table for storing installment data
	IF OBJECT_ID('tempdb..#installments') IS NULL
	BEGIN
		CREATE TABLE #installments
		(
			contract_id INT
			, number INT
			, expected_date DATETIME
			, principal MONEY
			, interest MONEY
			, paid_principal MONEY
			, paid_interest MONEY
			, paid_date DATETIME
		)
		CREATE INDEX IX_Contract_id ON #installments (contract_id) -- speed things up
	END
	TRUNCATE TABLE #installments
	INSERT INTO #installments SELECT * FROM dbo.InstallmentSnapshot(@beginDate)

	-- Create temporary table for storing penalties
	IF OBJECT_ID('tempdb..#penalties') IS NULL
	BEGIN
		CREATE TABLE #penalties
		(
			contract_id INT
			, penalty MONEY
		)
	END
	TRUNCATE TABLE #penalties

	-- Calculate penalties
	DECLARE @contract_id INT
	DECLARE cur CURSOR FOR SELECT id FROM dbo.ActiveLoans(@beginDate, @branch_id)
	OPEN cur
	FETCH NEXT FROM	cur
	INTO @contract_id
	WHILE 0 = @@FETCH_STATUS
	BEGIN
		EXEC dbo.CalculateLatePenalty @contract_id, @beginDate
		FETCH NEXT FROM cur
		INTO @contract_id
	END
	CLOSE cur
	DEALLOCATE cur

	-- Fetch data
	SELECT temp.id
	,temp.contract_code
	,temp.client_name
	,temp.district
	,temp.city
	,temp.loan_officer_name
	,temp.start_date
	,temp.late_days
	,temp.olb*dbo.GetXR(temp.currency_id, @display_in, @beginDate) AS olb
	,temp.amount*dbo.GetXR(temp.currency_id, @display_in, @beginDate) AS amount
	,temp.penalties*dbo.GetXR(temp.currency_id, @display_in, @beginDate) AS penalties
	,paid_principal
	,paid_interest
	,due_principal
	,due_interest
	,CASE WHEN paid_principal > due_principal THEN 0 ELSE due_principal - paid_principal END AS principal
	,CASE WHEN paid_interest > due_interest THEN 0 ELSE due_interest - paid_interest END AS interest
	,ISNULL(dbo.GetXR(temp.currency_id, @display_in, @beginDate), 0) AS exchange_rate
	,temp.phone_number
	FROM
	(
		SELECT al.id, c.contract_code
		, ISNULL(corp.name, ISNULL(g.name, prsn.first_name + ' ' + prsn.last_name)) AS client_name
		, d.name AS district
		, t.city
		, u.first_name + ' ' + u.last_name AS loan_officer_name
		, dbo.GetDisbursementDate(al.id) AS [start_date]
		, al.late_days
		, al.olb*dbo.GetXR(Pkgs.currency_id, @display_in, @beginDate) AS olb
		, cr.amount*dbo.GetXR(Pkgs.currency_id, @display_in, @beginDate) AS amount
		, p.penalty*dbo.GetXR(Pkgs.currency_id, @display_in, @beginDate) AS penalties
		, ISNULL(i.paid_principal, 0)*dbo.GetXR(Pkgs.currency_id, @display_in, @beginDate) AS paid_principal
		, ISNULL(i.paid_interest, 0)*dbo.GetXR(Pkgs.currency_id, @display_in, @beginDate) AS paid_interest
		, ISNULL(i.due_principal, 0)*dbo.GetXR(Pkgs.currency_id, @display_in, @beginDate) AS due_principal
		, ISNULL(i.due_interest, 0)*dbo.GetXR(Pkgs.currency_id, @display_in, @beginDate) AS due_interest
		, Pkgs.currency_id AS currency_id
		, i.expected_date AS expected_date
		, t.[home_phone]+SPACE(1)+t.[secondary_home_phone] AS phone_number
		FROM dbo.ActiveLoans(@beginDate, @branch_id) AS al
		LEFT JOIN #penalties AS p ON al.id = p.contract_id
		LEFT JOIN dbo.Contracts AS c ON c.id = al.id
		LEFT JOIN dbo.Credit AS cr ON cr.id = c.id
		LEFT JOIN dbo.Packages AS Pkgs ON Pkgs.id=cr.package_id
		LEFT JOIN dbo.Projects AS j ON j.id = c.project_id
		LEFT JOIN dbo.Tiers AS t ON t.id = j.tiers_id
		LEFT JOIN dbo.Persons AS prsn ON prsn.id = t.id
		LEFT JOIN dbo.Groups AS corp ON corp.id = t.id
		LEFT JOIN dbo.Groups AS g ON g.id = t.id
		LEFT JOIN dbo.Districts AS d ON d.id = t.district_id
		LEFT JOIN dbo.Users AS u ON u.id = cr.loanofficer_id
		LEFT JOIN
		(
			SELECT i.contract_id
			, MAX(expected_date) AS expected_date
			, SUM(i.principal) AS due_principal
			, SUM(i.interest) AS due_interest
            , SUM(i.paid_principal) paid_principal
            , SUM(i.paid_interest) paid_interest
			FROM #installments AS i
			WHERE i.expected_date <= @beginDate
			GROUP BY i.contract_id
		) AS i ON i.contract_id = al.id
		WHERE al.late_days > 0 AND p.penalty >= 0
		AND ((0 = @branch_id AND t.branch_id IN (SELECT branch_id FROM dbo.UsersBranches WHERE user_id = @user_id))
			OR t.branch_id = @branch_id)
		AND 
		(
			0 = @user_id OR 
			(
				0 = @subordinate_id AND cr.loanofficer_id IN (
					SELECT @user_id
					UNION ALL
					SELECT subordinate_id
					FROM dbo.UsersSubordinates
					WHERE user_id = @user_id
				)
				OR cr.loanofficer_id = @subordinate_id
			)
		)
	) AS temp
	WHERE (temp.currency_id=@disbursed_in OR @disbursed_in=0)
	ORDER BY loan_officer_name, late_days DESC
END
