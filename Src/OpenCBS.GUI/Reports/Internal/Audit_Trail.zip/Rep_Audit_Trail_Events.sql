CREATE PROCEDURE [dbo].[Rep_Audit_Trail_Events] 
    @from DATETIME
    , @to DATETIME
    , @user INT
    , @events NVARCHAR(MAX)
    , @include_deleted BIT
	, @suspicious_only BIT
AS 
BEGIN
    SELECT event_type, event_date, entry_date
      , user_name, user_role, description, deleted
    FROM AuditTrailEvents(@from, @to, @user, 0, @events, @include_deleted, @suspicious_only) 
END
