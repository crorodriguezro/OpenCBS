CREATE PROCEDURE dbo.Rep_Repayment_Schedule @contract_id INT
AS BEGIN
	 DECLARE @tempT TABLE(
	 number int null,
	 val Decimal(8,2) null
	 )
	
		 DECLARe @numb int  
		 Select top 1 @numb = number from dbo.Installments where contract_id = @contract_id order by number desc
  
	 Insert into @tempT (number, val) select number, olb from dbo.Installments where contract_id = @contract_id 
	 insert into @tempT (number, val) VALUES ((@numb+1), 0)
 
select 
  i.number as number ,
  convert( nchar(20),  i.expected_date, 106)  as paid_date,
  (ISNULL(i.interest,0)* 0.02)+ISNULL(i.interest,0)+ISNULL(i.principal,0) as total,
  i.interest* 0.02 as interestP,
  i.interest as interest,
  i.principal as principal,
  il.val as olb1
 from dbo.InstallmentSnapshot((Select c.start_date from dbo.Contracts c 
 where c.id = @contract_id))  i  
 LEFT JOIN @tempT  il On il.number-1 = (i.number) 
  where  i.contract_id =@contract_id  
 
END



 
 
 
