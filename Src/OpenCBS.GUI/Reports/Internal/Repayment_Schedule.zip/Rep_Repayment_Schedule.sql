CREATE PROCEDURE dbo.Rep_Repayment_Schedule @contract_id INT
AS BEGIN
	SELECT i.number, i.capital_repayment, i.interest_repayment,
	cr.amount - SUM(i2.capital_repayment) AS olb, i.capital_repayment + i.interest_repayment AS total,
	i.expected_date
	FROM dbo.Installments AS i
	LEFT JOIN dbo.Credit AS cr ON cr.id = i.contract_id
	LEFT JOIN dbo.Installments AS i2 ON i.contract_id = i2.contract_id AND i2.number <= i.number
	WHERE i.contract_id = @contract_id
	GROUP BY cr.amount, i.contract_id, i.number, i.capital_repayment, i.interest_repayment, i.expected_date
END