CREATE PROCEDURE dbo.Rep_Repayment_Schedule @contract_id INT
AS BEGIN
 --Declare @contract_id int =28 
 
	 DECLARE @tempT TABLE(
	 number int null,
	 val Decimal(8,2) null
	 )
	
		 DECLARe @numb int  
		 Select top 1 @numb = number from dbo.Installments where contract_id = @contract_id order by number desc
  
	 Insert into @tempT (number, val) select number, olb from dbo.Installments where contract_id = @contract_id 
	 insert into @tempT (number, val) VALUES ((@numb+1), 0)
 
select 
i.number as number ,
   convert( nchar(20),  i.expected_date, 106)  as paid_date,
  i.principal as principal,
  i.interest* 0.02 as interestP,
  i.interest as interest,
  i.principal + i.interest as total
  , il.val as olb1
 from dbo.InstallmentSnapshot((Select c.start_date from dbo.Contracts c 
 where c.id = @contract_id))  i  
 LEFT JOIN @tempT  il On il.number-1 = (i.number) 
  where  i.contract_id =@contract_id  
 
--SELECT 
--    i.number,
--    i.paid_date,
--    i.paid_capital,
--    i.paid_interest * 0.02 as paid,
--    i.paid_interest,
--    i.paid_capital ,
--    i.olb
--	FROM dbo.Installments AS i WHERE i.contract_id = @contract_id
	 
 	--SELECT i.number, i.capital_repayment, i.interest_repayment,
	--cr.amount - SUM(i2.capital_repayment) AS olb, i.capital_repayment + i.interest_repayment AS total,
	--i.expected_date
	--FROM dbo.Installments AS i
	--LEFT JOIN dbo.Credit AS cr ON cr.id = i.contract_id
	--LEFT JOIN dbo.Installments AS i2 ON i.contract_id = i2.contract_id AND i2.number <= i.number
	--WHERE i.contract_id = @contract_id
	--GROUP BY cr.amount, i.contract_id, i.number, i.capital_repayment, i.interest_repayment, i.expected_date
END



 
 
 
