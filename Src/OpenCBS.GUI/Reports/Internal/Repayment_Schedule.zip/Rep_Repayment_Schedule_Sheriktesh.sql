CREATE PROCEDURE Rep_Repayment_Schedule_Sheriktesh @contract_id INT, @user_id INT
AS BEGIN
	DECLARE @disb_date DATETIME
	SET @disb_date = ( SELECT event_date
					   FROM ContractEvents 
					   WHERE contract_id = @contract_id AND is_deleted = 0 AND event_type = 'LODE')

	SELECT c.contract_code, 
		   c.start_date,
		   c.close_date,
		   cr.amount,
		   dbo.getEntryFees(@contract_id) AS entry_fees,
		   cr.nb_of_installment,
		   Round(CAST ( (cr.interest_rate * 12*100) AS decimal (9,5)), 6) as interest_rate_year,
		   u.first_name + ' ' + u.last_name AS loan_officer,
		   t.id AS client_id,
		   d.name as district,
		   p.birth_place as cl_city,
		   t.address as cl_address, 
		   t.secondary_address as sec_address,
		   p.identification_data as ident_data,
	ISNULL(corp.[name], ISNULL(g.[name], p.first_name + ' ' + p.last_name)) AS client_name
	FROM dbo.Contracts AS c
	INNER JOIN dbo.Credit AS cr ON cr.id = c.id	
	INNER JOIN dbo.Users AS u ON cr.loanofficer_id = u.id
	INNER JOIN dbo.Projects AS j ON c.project_id = j.id
	INNER JOIN dbo.Tiers AS t ON j.tiers_id = t.id
	INNER JOIN dbo.Districts AS d ON d.id = t.district_id
	INNER JOIN dbo.Packages ON Packages.id= cr.package_id
	LEFT JOIN dbo.LoanEntryFees(@disb_date,@disb_date,@user_id, 0, 1) lee ON lee.contract_id = c.id
	LEFT JOIN dbo.Persons AS p ON t.id = p.id
	LEFT JOIN dbo.Groups AS g ON t.id = g.id
	LEFT JOIN dbo.Corporates AS corp ON t.id = corp.id
	WHERE c.id = @contract_id
END


