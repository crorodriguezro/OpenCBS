CREATE PROCEDURE Rep_Client_Solidarity_Group_Information_Savings
	@group_id INT
AS BEGIN
	SELECT DISTINCT
	SaCont.code AS [savings_code],
	Balance.balance_amount,
	SaPr.name AS [product_name],
	SaPr.code AS [product_code],
	CASE 
	WHEN SaPr.product_type = 'B' THEN 'Savings Book'
	WHEN SaPr.product_type = 'C' THEN 'Compulsory savings'
	ELSE 'Savings Deposit'
	END
	AS [product_type],
	SaCont.creation_date, SaCont.closed_date
	FROM SavingContracts AS SaCont
	INNER JOIN SavingProducts AS SaPr ON SaPr.id = SaCont.product_id
	INNER JOIN
	(
	SELECT sum_deposit - ISNULL(sum_withdraw, 0) AS [balance_amount], Deposit.contract_id
	FROM
	(
		SELECT SUM(amount) AS [sum_deposit], contract_id
		FROM SavingEvents
		WHERE (code IN ('SVIE', 'SVDE', 'SIPE', 'SCTE')) AND deleted = 0 AND is_fired = 1 AND creation_date <= GETDATE()
		GROUP BY contract_id
	) AS Deposit
	LEFT JOIN
	(
		SELECT SUM(amount + ISNULL(fees, 0)) AS [sum_withdraw], contract_id
		FROM SavingEvents
		WHERE (code IN ('SVWE', 'SDTE')) AND deleted = 0 AND is_fired = 1 AND creation_date <= GETDATE() 
		GROUP BY contract_id
	) AS Withdraw ON Deposit.contract_id = Withdraw.contract_id
	) AS Balance ON Balance.contract_id = SaCont.id
	WHERE  SaCont.tiers_id = @group_id
END
