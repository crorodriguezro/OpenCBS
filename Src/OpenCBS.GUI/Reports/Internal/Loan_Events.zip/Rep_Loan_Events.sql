CREATE PROCEDURE Rep_Loan_Events
	@contract_id INT
AS BEGIN
	SELECT 
	ce.event_date AS date, 
	ce.entry_date AS entry_date,
	CASE WHEN ce.event_type='LOVE' THEN 'Loan Validation'
		WHEN ce.event_type='LODE' THEN 'Loan Disbursement'
		WHEN ce.event_type='RGLE' THEN 'Repayment of Good Loan'
		WHEN ce.event_type='RBLE' THEN 'Repayment of Bad Loan'
		WHEN ce.event_type='WROE' THEN 'WRite-Off'
		WHEN ce.event_type='ROWE' THEN 'Repayment Over Write-Off'
		WHEN ce.event_type='ROLE' THEN 'Reschedule Of Loan'
		WHEN ce.event_type='RRLE' THEN 'Repayment for Rescheduled Loan'
		WHEN ce.event_type='TEET' THEN 'Tranche Event'
		WHEN ce.event_type='APR'  THEN 'Anticipated Partial Repayment'
		WHEN ce.event_type='ATR'  THEN 'Anticipated Total Repayment'
		WHEN ce.event_type='ATPR' THEN 'Anticipated Total Partial Repayment'
		WHEN ce.event_type='GLLL' THEN 'Good Loan Late Loan'
		WHEN ce.event_type='GLBL' THEN 'Good Loan Bad Loan'
		WHEN ce.event_type='LLGL' THEN 'Late Loan Good Loan'
		WHEN ce.event_type='LLBL' THEN 'Late Loan Bad Loan'
		WHEN ce.event_type='BLGL' THEN 'Bad Loan Good Loan'
		WHEN ce.event_type='BLLL' THEN 'Bad Loan Late Loan'
        WHEN ce.event_type='AILE' THEN 'Accrual Interest Event'
        WHEN ce.event_type='LPAE' THEN 'Accrual Penalty Event'
        WHEN ce.event_type='IWOE' THEN 'Interest write off'
        WHEN ce.event_type='PWOE' THEN 'Penalty wirte off'
        WHEN ce.event_type in ('LEE0', 'LEE1', 'LEE2', 'LEE3', 'LEE4') THEN 'Entry Fee Event'
        WHEN ce.event_type='LOCE' THEN 'Loan Close Event'
	END AS event_type, 
	principal = COALESCE(lde.amount,re.principal,woe.olb,rle.amount,te.amount),
	interest = COALESCE(re.interests,woe.accrued_interests,rle.interest,te.applied_new_interest,aile.interest,iwoe.amount),
	commissions = COALESCE(lde.fees,re.commissions,lefe.fee),
	penalties = COALESCE(re.penalties,woe.accrued_penalties,lpae.penalty,pwoe.amount),
	u.first_name + SPACE(1) + u.last_name AS loan_officer,
	ce.is_deleted AS event_deleted
	FROM ContractEvents ce
	INNER JOIN Users u ON ce.user_id = u.id 
	LEFT JOIN LoanDisbursmentEvents lde ON ce.id = lde.id
    LEFT JOIN LoanEntryFeeEvents lefe ON ce.id = lefe.id
	LEFT JOIN AccrualInterestLoanEvents aile ON ce.id = aile.id
    LEFT JOIN LoanPenaltyAccrualEvents lpae ON ce.id = lpae.id
    LEFT JOIN InterestWriteOffEvents iwoe ON ce.id = iwoe.id
    LEFT JOIN PenaltyWriteOffEvents pwoe ON ce.id = pwoe.id 
	LEFT JOIN ( SELECT id,SUM(principal) AS principal,SUM(interests) AS interests,SUM(commissions) AS commissions,SUM(penalties) AS penalties
				FROM RepaymentEvents 				
				GROUP BY id ) re ON ce.id = re.id 
	LEFT JOIN ReschedulingOfALoanEvents rle ON ce.id = rle.id 	
	LEFT JOIN WriteOffEvents woe ON ce.id = woe.id 
	LEFT JOIN TrancheEvents te ON ce.id = te.id
	WHERE ce.contract_id = @contract_id AND ce.event_type NOT IN ('PDLE','LIAE')
	ORDER BY ce.event_date
END
