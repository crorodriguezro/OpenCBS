CREATE PROCEDURE Rep_Committee_Appraisal
@contract_id int
AS BEGIN
SELECT 
contracts.id as contract_id,
contracts.status,
credit_commitee_comment,
credit_commitee_code,
credit_commitee_date,
credit.amount,
ISNULL(groups.name, ISNULL(persons.first_name + ' ' + persons.last_name, corporates.name)) as client_name,
tiers.address,
tiers.city,
districts.name as district,
packages.name as product,
users.first_name + ' ' + users.last_name as loan_officer,
credit.interest_rate as interest_rate,
credit.nb_of_installment,
credit.grace_period,
currencies.name as currency,
DATEDIFF(m, contracts.start_date, contracts.close_date) as loan_length
FROM Corporates RIGHT OUTER JOIN
Persons RIGHT OUTER JOIN
Groups RIGHT OUTER JOIN
currencies 
inner join packages on currencies.id = packages.currency_id
inner join credit on credit.package_id = packages.id
inner join users on credit.loanofficer_id = users.id
inner join contracts on contracts.id = credit.id 
inner join projects on contracts.project_id = projects.id
inner join tiers on projects.tiers_id = tiers.id on groups.id = tiers.id on persons.id = tiers.id on corporates.id = tiers.id
inner join districts on districts.id = tiers.district_id
where contracts.id = @contract_id
END

