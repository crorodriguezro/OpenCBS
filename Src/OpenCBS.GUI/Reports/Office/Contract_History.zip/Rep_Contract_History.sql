--declare @loanId INT = 12, @clientId Int = 11

SELECT  co.contract_code,
	convert(date, co.[start_date]) as start_date,
	cr.amount,
	ISNULL(dbo.getEntryFees(@loanId),0) AS entry_fees,
	cr.[nb_of_installment],
	cr.interest_rate*100 as interest_rate,
	curr.name as currency_name,
	curr.code as symbol_currency,
	br.name AS branch,
	u.first_name + ' ' + u.last_name AS loan_officer,
	 (SELECT [value]
		FROM [GeneralParameters] WHERE [KEY] = 'MFI_NAME') AS mfi_name,
	COALESCE(pe.first_name + ' ' + pe.last_name, gr.name,corp.name) AS client_name,	
	COALESCE(pe.identification_data, corp.siret) AS passport	
FROM Contracts co
INNER JOIN Credit cr ON co.id = cr.id
INNER JOIN Packages pkg ON cr.package_id=pkg.id
INNER JOIN Currencies curr ON pkg.currency_id=curr.id
INNER JOIN Users u ON cr.loanofficer_id = u.id
INNER JOIN Projects pr ON co.project_id = pr.id
INNER JOIN Tiers ti ON ti.id = pr.tiers_id 
INNER JOIN Branches br ON br.code = co.branch_code
LEFT JOIN Persons pe ON pe.id = ti.id 
LEFT JOIN Groups gr ON gr.id=ti.id
LEFT JOIN Corporates corp ON corp.id = ti.id
WHERE co.id = @loanId

select
    ce.event_type
    , case
        when ce.event_type = 'LODE' then 'Disbursement'
        when ce.event_type in ('RGLE', 'RBLE') then 'Repayment'
        when ce.event_type = 'APR' then 'Early Partial Repayment'
        when ce.event_type = 'ATR' then 'Early Total Repayment'
    end name
    , ce.event_date
    , coalesce(lode.amount, re.principal) principal
    , case
        when ce.event_type = 'LODE' then 0
        else re.interests
    end interests
    , case
        when ce.event_type = 'LODE' then 0
        else re.commissions + re.bounce_fee
    end fees
    , case
        when ce.event_type = 'LODE' then 0
        else re.past_due_days
    end late_days
from
    dbo.ContractEvents ce
left join
    dbo.LoanDisbursmentEvents lode on lode.id = ce.id 
left join
    dbo.RepaymentEvents re on re.id = ce.id
where
    ce.contract_id = @loanId
    and ce.is_deleted = 0
    and ce.event_type in ('LODE', 'RGLE', 'RBLE', 'ATR', 'APR')

SELECT  i.number,
                i.[capital_repayment],
                i.[interest_repayment],
                i.[capital_repayment] + i.[interest_repayment] - i.paid_capital - i.paid_interest AS total,
				i.paid_interest,
				i.paid_capital,
                convert(date, i.[expected_date]) as expected_date,
                case when i.[capital_repayment] + i.[interest_repayment] - i.paid_capital - i.paid_interest <0.2
				then (select convert(date, max(paid_date)) from installments 
				where installments.contract_id=i.contract_id and installments.number<=i.number) else NULL end as paid_date
        FROM    [Installments] AS i
        WHERE   [contract_id] = @loanId
        ORDER BY i.[number] ASC