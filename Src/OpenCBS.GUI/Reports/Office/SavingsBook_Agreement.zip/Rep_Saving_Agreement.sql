--Declare @savingsId INT = 12
	SELECT	SavingContracts.code AS "contract_code", 
			SavingContracts.creation_date AS "contract_creation_date",
			SavingProducts.name AS "product_name",
			ISNULL(Groups.name,Persons.first_name + SPACE(1) + Persons.last_name) AS "client_name",
			Districts.name AS "district_name",
			SavingContracts.interest_rate * 100 AS "interest_rate",
			SavingProducts.balance_max AS "balance_max",
			SavingProducts.balance_min AS "balance_min", 
			SavingProducts.initial_amount_min AS "initial_amount_min",
			SavingProducts.initial_amount_max AS "initial_amount_max", 
			SavingProducts.deposit_max AS "deposit_max", 
			SavingProducts.deposit_min AS "deposit_min", 
			SavingProducts.withdraw_max AS "withdraw_max", 
			SavingProducts.withdraw_min AS "withdraw_min",
			SavingProducts.transfer_min AS "transfer_min",
			SavingProducts.transfer_max AS "transfer_max",
			CASE SavingBookProducts.withdraw_fees_type
				WHEN 1 THEN CONVERT(VARCHAR, 'Flat')
				WHEN 2 THEN CONVERT(VARCHAR, 'Rate')
			END AS "withdrawal_fees_type",
			CASE SavingBookProducts.withdraw_fees_type
				WHEN 1 THEN SavingBookContracts.flat_withdraw_fees
				WHEN 2 THEN SavingBookContracts.rate_withdraw_fees * 100
			END AS "withdrawal_fees",
			CASE SavingBookProducts.transfer_fees_type
				WHEN 1 THEN CONVERT(VARCHAR, 'Flat')
				WHEN 2 THEN CONVERT(VARCHAR, 'Rate')
			END AS "transfer_fees_type",
			CASE SavingBookProducts.transfer_fees_type
				WHEN 1 THEN SavingBookContracts.flat_transfer_fees
				WHEN 2 THEN SavingBookContracts.rate_transfer_fees * 100
			END AS "transfer_fees",
			SavingProducts.entry_fees AS "entry_fees",
			CASE SavingBookProducts.interest_frequency 
				WHEN 10 THEN CONVERT(VARCHAR, 'End of Day')
				WHEN 20 THEN CONVERT(VARCHAR, 'End of Week')
				WHEN 30 THEN CONVERT(VARCHAR, 'End of Month')
				WHEN 40 THEN CONVERT(VARCHAR, 'End of Year')
			END	AS "interest_frequency",
			CASE SavingBookProducts.interest_base 
				WHEN 10 THEN CONVERT(VARCHAR, 'Daily')
				WHEN 20 THEN CONVERT(VARCHAR, 'Weekly')
				WHEN 30 THEN CONVERT(VARCHAR, 'Monthly')
			END AS "interest_base",
			Currencies.code as "currency_code"
	FROM [dbo].[SavingContracts]
	INNER JOIN [dbo].[SavingProducts] ON SavingContracts.product_id = SavingProducts.id
	INNER JOIN [dbo].[Tiers] ON SavingContracts.tiers_id = Tiers.id
	INNER JOIN [dbo].[Districts] ON Districts.id = Tiers.district_id
	INNER JOIN [dbo].[Currencies] ON SavingProducts.currency_id = Currencies.id
	LEFT OUTER JOIN [dbo].[SavingBookProducts] ON SavingBookProducts.id = SavingProducts.id
	LEFT OUTER JOIN [dbo].[SavingBookContracts] ON SavingBookContracts.id = SavingContracts.id
	LEFT OUTER JOIN [dbo].[Persons] ON Tiers.id = Persons.id 
	LEFT OUTER JOIN [dbo].[Groups] ON Tiers.id = Groups.id
	WHERE SavingContracts.id = @savingsId
