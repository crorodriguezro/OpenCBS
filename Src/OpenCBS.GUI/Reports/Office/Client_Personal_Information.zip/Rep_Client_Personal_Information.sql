--declare @clientId INT = 78

IF OBJECT_ID('tempdb..#thumbnails') IS NOT NULL
BEGIN
   DROP TABLE #thumbnails
END

CREATE TABLE #thumbnails	
(
	num INT NOT NULL
	, thumbnail1 IMAGE NULL
	, thumbnail2 IMAGE NULL	
)

DECLARE @db_from NVARCHAR(MAX)
DECLARE @db_to NVARCHAR(MAX)
DECLARE @sql NVARCHAR(MAX)

SELECT @db_from = DB_NAME()
SET @db_to = @db_from + '_attachments'

IF EXISTS (SELECT * FROM sys.databases WHERE name = @db_to)
BEGIN
	SET @sql = 'INSERT INTO #thumbnails (num, thumbnail1)
	SELECT 1, thumbnail
	FROM ' + @db_to + '..Pictures
	WHERE id = ' + CAST(@clientId AS NVARCHAR(20)) + ' AND subid = 0'
	EXEC sp_executesql @sql	

	SET @sql = 'INSERT INTO #thumbnails (num, thumbnail2)
	SELECT 2, thumbnail
	FROM ' + @db_to + '..Pictures
	WHERE id = ' + CAST(@clientId AS NVARCHAR(20)) + ' AND subid = 1'
	EXEC sp_executesql @sql	
END

SELECT
Pers.first_name dFirstName
,Pers.last_name dLastName
,Pers.father_name dFatherName
,Pers.identification_data AS dIDNumber
,convert(date, Pers.birth_date) as dDateOfBirth
,Pers.sex AS dGender
,ISNULL(Dis.name, '-') AS dDistrict
,ISNULL(Tr.city, '-') AS dCity
,ISNULL(Tr.address, '-') AS dAddress
,ISNULL(Dis2.name, '-') AS dbDistrict
,ISNULL(Tr.secondary_city, '-') AS dbCity
,ISNULL(Tr.secondary_address, '-') AS dbAddress
,ISNULL(Tr.personal_phone, '-') AS dPhone
,ISNULL(Tr.secondary_home_phone, '-') AS dbPhone1
,ISNULL(Tr.secondary_personal_phone, '-') AS dbPhone2
, th1.thumbnail1 dPicture1
, th2.thumbnail2 dPicture2
FROM Tiers AS Tr
INNER JOIN Persons AS Pers ON Pers.id = Tr.id
LEFT JOIN Districts AS Dis ON Dis.id = Tr.district_id
LEFT JOIN Districts AS Dis2 ON Dis2.id = Tr.secondary_district_id
LEFT JOIN #thumbnails th1 ON th1.num = 1
LEFT JOIN #thumbnails th2 ON th2.num = 2
WHERE Tr.id = @clientId

SELECT DISTINCT
Cont.contract_code, 
dbo.Statuses.Status_name AS [status],
CASE WHEN LoSh.amount IS NOT NULL THEN LoSh.amount ELSE Cr.amount END AS [amount],
ISNULL(AcLo.olb, '') AS [olb], 
convert(date, Cont.creation_date) as creation_date, convert(date, Cont.start_date) as start_date, convert(date, Cont.close_date) as close_date, 
ISNULL(Gr.name, '-') AS [group_name], 
CASE WHEN AcLo.late_days IS NOT NULL AND AcLo.late_days!=0 THEN total_late_days
ELSE total_late_days END
AS [total_late_days],
CAST(CASE WHEN ContEv.count_atr > 0 THEN 1 ELSE 0 END AS BIT) AS has_atr
FROM Contracts AS Cont
INNER JOIN Credit As Cr On Cr.id = Cont.id
INNER JOIN Projects AS Pr ON Cont.project_id = Pr.id
INNER JOIN Tiers AS Tr ON Tr.id = Pr.tiers_id
LEFT JOIN ActiveLoans(GETDATE(), 0) AS AcLo ON AcLo.id = Cont.id
LEFT JOIN LoanShareAmounts AS LoSh ON LoSh.contract_id = Cont.id
LEFT JOIN Groups AS Gr On Gr.id = LoSh.group_id
INNER JOIN 
(
SELECT     Installments.contract_id, 
SUM (
	  CASE WHEN Installments.expected_date IS NULL AND Installments.paid_date IS NULL THEN 0
	  ELSE
		  CASE WHEN  Installments.paid_date IS NULL THEN 
			    CASE WHEN DATEDIFF(dd, Installments.expected_date, GETDATE())<0 THEN 0
				     ELSE DATEDIFF(dd, Installments.expected_date, GETDATE()) 
					 END
				ELSE CASE WHEN DATEDIFF(dd, Installments.expected_date, paid_date)<0 THEN 0 
					 ELSE DATEDIFF(dd, Installments.expected_date, paid_date)
				     END
				END
		  END
	)AS total_late_days
FROM      dbo.Installments
GROUP BY Installments.contract_id
) AS Ins ON Ins.contract_id = Cont.id INNER JOIN
dbo.Statuses ON Cont.status = dbo.Statuses.id
LEFT JOIN
(
SELECT
contract_id, COUNT(id) AS [count_atr]
FROM ContractEvents AS ContEv
WHERE ContEv.event_type = 'ATR' AND ContEv.is_deleted = 0
GROUP BY contract_id
) AS ContEv ON ContEv.contract_id = Cont.id
WHERE (Tr.id = @clientId OR LoSh.person_id = @clientId)

SELECT DISTINCT
SaCont.code AS [savings_code],
Balance.balance_amount,
SaPr.name AS [product_name],
SaPr.code AS [product_code],
CASE 
WHEN SaPr.product_type = 'B' THEN 'Savings Book'
WHEN SaPr.product_type = 'C' THEN 'Compulsory savings'
ELSE 'Savings Deposit'
END
AS [product_type],
convert(date, SaCont.creation_date) as creation_date, convert(date, SaCont.closed_date) as closed_date
FROM SavingContracts AS SaCont
INNER JOIN SavingProducts AS SaPr ON SaPr.id = SaCont.product_id
INNER JOIN
(
SELECT sum_deposit - ISNULL(sum_withdraw, 0) AS [balance_amount], Deposit.contract_id
FROM
(
	SELECT SUM(amount) AS [sum_deposit], contract_id
	FROM SavingEvents
	WHERE (code IN ('SVIE', 'SVDE', 'SIPE', 'SCTE')) AND deleted = 0 AND is_fired = 1 AND creation_date <= GETDATE()
	GROUP BY contract_id
) AS Deposit
LEFT JOIN
(
	SELECT SUM(amount + ISNULL(fees, 0)) AS [sum_withdraw], contract_id
	FROM SavingEvents
	WHERE (code IN ('SVWE', 'SDTE')) AND deleted = 0 AND is_fired = 1 AND creation_date <= GETDATE() 
	GROUP BY contract_id
) AS Withdraw ON Deposit.contract_id = Withdraw.contract_id
) AS Balance ON Balance.contract_id = SaCont.id
WHERE  SaCont.tiers_id = @clientId