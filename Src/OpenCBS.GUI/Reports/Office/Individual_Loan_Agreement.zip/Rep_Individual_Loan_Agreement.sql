--declare @contract_id INT = 12

SELECT LEFT(credit.amount,LEN(credit.amount)-3) AS amountb,credit.interest_rate, NB_OF_INSTALLMENT, CONTRACT_CODE, start_date, 
	   persons.first_name+' '+persons.last_name AS client_name,
	   [father_name],[identification_data],users.first_name+' '+users.[last_name] AS lo_name, 	   
	   ISNULL (dbo.getEntryFees(@contract_id),0) AS entry_fees,
	   credit.[non_repayment_penalties_based_on_overdue_principal],

	   (SELECT [value]
		FROM [GeneralParameters] WHERE [KEY] = 'MFI_NAME') AS mfi_name,
	    
	   LEFT((SELECT (SUM([Installments].[capital_repayment]+[Installments].[interest_repayment]))
	    FROM [Installments] WHERE [Installments].[contract_id] = @contract_id),LEN((SELECT (SUM([Installments].[capital_repayment]+[Installments].[interest_repayment]))
	    FROM [Installments] WHERE [Installments].[contract_id] = @contract_id))-3) AS loan_cost,
	    
	    LEFT((SELECT ([Installments].[capital_repayment]+[Installments].[interest_repayment]) 
	    FROM [Installments] WHERE [Installments].[contract_id] = @contract_id AND number=1),(LEN((SELECT ([Installments].[capital_repayment]+[Installments].[interest_repayment]) 
	    FROM [Installments] WHERE [Installments].[contract_id] = @contract_id AND number=1))-3)) AS instalment_cost,
	    c.name AS curname,
		100*credit.interest_rate AS interest_rate_percentage,
		currencies.code AS currency_code,
	    100*credit.non_repayment_penalties_based_on_overdue_principal AS penalties_overdue_principal,
		100*credit.non_repayment_penalties_based_on_olb AS penalties_olb,
		100*credit.non_repayment_penalties_based_on_initial_amount AS penalties_initial_amount,
		100*credit.non_repayment_penalties_based_on_overdue_interest AS penalties_overdue_interest,
		InstallmentTypes.name AS installment_type,
		Branches.name AS branch,
		100*credit.anticipated_total_repayment_penalties AS atr_percentage,
		100*credit.anticipated_partial_repayment_penalties AS apr_percentage,
	    CASE 
		WHEN packages.anticipated_total_repayment_base=2 THEN 'OLB' 
		ELSE 'interest'
		END AS atr_type,
		
		CASE 
		WHEN Packages.anticipated_partial_repayment_base=2 THEN 'OLB' 
		WHEN Packages.anticipated_partial_repayment_base=3 THEN  'prepaid principal'
		ELSE 'interest'
		END AS apr_type

FROM credit 
	INNER JOIN 	 contracts ON CONTRACts.id =credit.id 
    INNER JOIN 	Packages ON Packages.id=credit.package_id
	INNER JOIN 	 projects ON projects.id = contracts.[project_id]
	INNER JOIN 	 tiers ON [Tiers].id = projects.[tiers_id] 
	INNER JOIN	 persons ON persons.id = tiers.id
	INNER JOIN currencies ON currencies.id=Packages.currency_id 
	INNER JOIN InstallmentTypes ON InstallmentTypes.id=Packages.installment_type
	INNER JOIN Branches ON Branches.code=contracts.branch_code
	INNER JOIN	 [Users] ON [Users].id = [loanofficer_id]
	LEFT JOIN	 Currencies c ON c.id = Packages.currency_id
	 
WHERE credit.id=@contract_id

