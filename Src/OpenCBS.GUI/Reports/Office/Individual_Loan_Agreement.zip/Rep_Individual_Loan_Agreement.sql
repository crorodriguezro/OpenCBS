--declare @contract_id INT = 12

SELECT LEFT(credit.amount,LEN(credit.amount)-3) AS amount,credit.interest_rate, NB_OF_INSTALLMENT, CONTRACT_CODE, start_date, 
	   persons.first_name+' '+persons.last_name AS client_name,
	   [father_name],[identification_data],users.first_name+' '+users.[last_name] AS lo_name, 	   
	   dbo.getEntryFees(@contract_id) AS entry_fees,
	   credit.[non_repayment_penalties_based_on_overdue_principal],
	   (SELECT [value] 
	    FROM [GeneralParameters] WHERE [KEY] = 'BRANCH_NAME') AS branch_name,
	    
	   LEFT((SELECT (SUM([Installments].[capital_repayment]+[Installments].[interest_repayment]))
	    FROM [Installments] WHERE [Installments].[contract_id] = @contract_id),LEN((SELECT (SUM([Installments].[capital_repayment]+[Installments].[interest_repayment]))
	    FROM [Installments] WHERE [Installments].[contract_id] = @contract_id))-3) AS loan_cost,
	    
	    LEFT((SELECT ([Installments].[capital_repayment]+[Installments].[interest_repayment]) 
	    FROM [Installments] WHERE [Installments].[contract_id] = @contract_id AND number=1),(LEN((SELECT ([Installments].[capital_repayment]+[Installments].[interest_repayment]) 
	    FROM [Installments] WHERE [Installments].[contract_id] = @contract_id AND number=1))-3)) AS instalment_cost,
	    c.name AS curname
	   
FROM credit 
	INNER JOIN 	 contracts ON CONTRACts.id =credit.id 
    INNER JOIN 	Packages ON Packages.id=credit.package_id
	INNER JOIN 	 projects ON projects.id = contracts.[project_id]
	INNER JOIN 	 tiers ON [Tiers].id = projects.[tiers_id] 
	INNER JOIN	 persons ON persons.id = tiers.id 
	INNER JOIN	 [Users] ON [Users].id = [loanofficer_id]
	LEFT JOIN	 Currencies c ON c.id = Packages.currency_id
	 
WHERE credit.id=@contract_id