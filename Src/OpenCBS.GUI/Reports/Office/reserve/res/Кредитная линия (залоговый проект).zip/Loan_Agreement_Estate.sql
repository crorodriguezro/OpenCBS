﻿--declare @loanId int =1
	DECLARE @cashflows TABLE
	(
		n FLOAT
		, amount MONEY
	)

	DECLARE @start_date DATETIME
	SELECT @start_date=start_date
	FROM dbo.Contracts WHERE id = @loanId

	INSERT INTO @cashflows
	SELECT 0, -cr.amount + ISNULL(dbo.getEntryFees(@loanId), 0)
	FROM dbo.Credit cr
	WHERE cr.id = @loanId

	INSERT INTO @cashflows
	SELECT -DATEDIFF(dd, @start_date, expected_date)/365.0, capital_repayment + interest_repayment
	FROM dbo.Installments
	WHERE contract_id = @loanId
	
	DECLARE @rate FLOAT
	DECLARE @temp FLOAT
	SET @rate = 0
	DECLARE @err FLOAT
	SET @err = .00000001

	DECLARE @val FLOAT
	DECLARE @pval FLOAT

	DECLARE @i INT
	SET @i = 0
	WHILE @i < 10
	BEGIN
		SELECT @val = SUM(amount * POWER(1 + @rate, n)) FROM @cashflows
		SELECT @pval = SUM(amount * n * POWER(1 + @rate, n - 1)) FROM @cashflows
		SET @temp = @rate - @val/@pval
		IF ABS(@temp - @rate) < @err
		BEGIN
			SET @rate = @temp
			BREAK
		END
		SET @rate = @temp
		SET @i = @i + 1
	END
	--end of calculating

	SELECT co.contract_code,b.director_nominative,
	dbo.DateToString(co.close_date)+ N' года'  close_date,
	dbo.DateToString((SELECT expected_date FROM installments WHERE contract_id = cr.id and number=(select MAX(number) from Installments where contract_id=cr.id)))+ N' года' AS contract_close_date,
	dbo.DateToString(co.start_date) + N' года' start_date,
	(SELECT MIN(id) FROM ContractEvents WHERE contract_id = cr.id) AS love_id,
	ISNULL(pe.last_name,'') +' '+ ISNULL(pe.first_name,'')+' '+ISNULL(pe.father_name,'') AS client_name,
	ISNULL(pe.last_name,'') +' '+ ISNULL(LEFT(pe.first_name,1),'')+'. '+ISNULL(LEFT(pe.father_name,1),'')+'.' AS client_short_name,
	pe.identification_data,
    ISNULL(co.loan_purpose, '') AS purpose_of_loan,
    cr.amount,
    pkg.name AS package_name,
    dbo.Stringify('D[ru]', ISNULL(cr.amount,0)) AS amount_words,
    cast(cr.interest_rate as numeric(10,4)) as interest_rate,
    cast(cr.interest_rate*100 as numeric(10,2)) as IR_monthly,    
    dbo.Stringify('D[ru]', ISNULL(ROUND(cr.interest_rate*100,0,1),0)) AS i_r_words_decimal,
    dbo.Stringify('D[ru]', ISNULL((cr.interest_rate*100-ROUND(cr.interest_rate*100,0,1))*100,0)) AS i_r_words_cents,
    cast(cr.interest_rate*1200 as numeric(10,2)) AS ir_12,
    dbo.Stringify('D%[ru]', ISNULL(cr.interest_rate*1200,0)) AS ir12_words,
    cr.nb_of_installment,
    dbo.Stringify('D[ru]', ISNULL(cr.nb_of_installment,0)) AS nb_of_ins_words,
    round(@rate*100,2) AS eir,
    dbo.Stringify('D%[ru]', @rate*100) AS eir_words,
    dbo.getEntryFees(@loanId)/cr.amount*100 AS entry_fees,
    cr.anticipated_total_repayment_penalties AS apr_rate,
    dbo.Stringify('D%[ru]', cr.anticipated_partial_repayment_base) AS apr_rate_words,
    cr.non_repayment_penalties_based_on_overdue_interest*100 AS lateFee_interest,
    cr.non_repayment_penalties_based_on_overdue_principal*100 AS lateFee_principal,
    d.name AS cl_district,
    ti.city AS cl_city,
    ti.[address] AS cl_adress,
    ISNULL(d.name,'') +', '+ ISNULL(ti.city,'')+', '+ISNULL(ti.[address],'')+'   T. '+ISNULL(ti.home_phone,'')+' '+ISNULL(ti.personal_phone,'') AS client_full_adress,
    ti.home_phone AS home_phone,
    ti.personal_phone AS personal_phone,
    convert(nvarchar(10),pe.birth_date,104) as birth_date,
    b.city AS br_city,
    b.director AS br_director,
    b.agreement AS agreement,
    convert(nvarchar(10),b.date_of_agreement,104) AS date_of_agreement,
    b2.[address] AS branch_adress,
    b2.id,
    b2.name,
    b.tin,
    b2.[description],
    pkg.id AS package_ID,
    CASE 
		 WHEN dbo.GetAdvancedFieldValue(@loanId, 'L', N'Код контракта*') IS NULL  THEN '_________'
		 ELSE dbo.GetAdvancedFieldValue(@loanId, 'L', N'Код контракта*')
	END AS contract_custom_code,
	CASE WHEN cl.id IS NULL THEN '_' ELSE '|' END AS is_collateral,
	CASE WHEN gr.tiers_id IS NULL THEN '_' ELSE '|' END AS is_guarantor,
	
	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Описание' ) AS Collateral_description,
	
	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Адрес' ) AS Collateral_address,

	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Правоустанавливающий документ' ) AS Collateral_docs,
	
	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Идентификационный код' ) AS Collateral_identification,

	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Оценочная стоимость' ) AS Collateral_price,
	
	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Мера' ) AS Collateral_square_area,
	
	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Общая полезная  площадь' ) AS Collateral_square_total,
	
	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Общая полезная жилая площадь' ) AS Collateral_square_inhabit
	
	FROM   Credit cr
	INNER JOIN Contracts co ON co.id =cr.id
	INNER JOIN Packages pkg ON pkg.id=cr.package_id
	INNER JOIN Projects pr ON pr.id = co.[project_id]
	INNER JOIN Tiers ti ON ti.id = pr.tiers_id
	INNER JOIN Persons pe ON pe.id = ti.id
	INNER JOIN Users u ON u.id = cr.loanofficer_id
	INNER JOIN Districts d ON d.id = ti.district_id
	LEFT JOIN Branchinfo b ON b.branch_id = ti.branch_id
	LEFT JOIN Branches b2 ON b2.id = ti.branch_id
	LEFT JOIN CollateralsLinkContracts cl on cl.contract_id = cr.id
	LEFT JOIN LinkGuarantorCredit gr on gr.contract_id = cr.id 
	WHERE cr.id=@loanId