﻿--declare @loanID int=787


select top 1 convert(nvarchar(10),ce.event_date,104) as event_date,
te.amount,dbo.Stringify('D[ru]', ISNULL(te.amount,0)) AS amount_in_words,cast(te.interest_rate*1200 as numeric(10,2)) as IR_rate,
cast(te.interest_rate*100 as numeric(10,2)) as IR_monthly,
c.contract_code as contract_code,
cr.nb_of_installment,

case b2.id
when 1 then 1.5 
when 2 then 1.7
end as commission,

ISNULL(c.loan_purpose, '') AS purpose_of_loan,
dbo.Stringify('D[ru]', ISNULL(cr.nb_of_installment,0)) AS nb_of_ins_words,
dbo.DateToString(c.start_date) + N' года' start_date,
dbo.DateToString((SELECT expected_date FROM installments WHERE contract_id = cr.id and number=(select MAX(number) from Installments where contract_id=cr.id))) + N' года'  AS contract_close_date,
d.name AS cl_district,
ti.city AS cl_city,
ti.[address] AS cl_adress,
ISNULL(pe.last_name,'') +' '+ ISNULL(pe.first_name,'')+' '+ISNULL(pe.father_name,'') AS client_name,
ISNULL(pe.last_name,'') +' '+ ISNULL(LEFT(pe.first_name,1),'')+'. '+ISNULL(LEFT(pe.father_name,1),'')+'.' AS client_short_name,
pe.identification_data,
ISNULL(d.name,'') +', '+ ISNULL(ti.city,'')+', '+ISNULL(ti.[address],'')+'   T. '+ISNULL(ti.home_phone,'')+' '+ISNULL(ti.personal_phone,'') AS client_full_adress,
ti.home_phone AS home_phone,
ti.personal_phone AS personal_phone,
convert(nvarchar(10),pe.birth_date,104) as birth_date,
b.city AS br_city,
b.director AS br_director,
b.agreement AS agreement,
convert(nvarchar(10),b.date_of_agreement,104) AS date_of_agreement,
b2.[address] AS branch_adress

from dbo.ContractEvents ce
inner join dbo.TrancheEvents te on te.id = ce.id
inner join dbo.Contracts c on c.id=ce.contract_id
inner join dbo.Credit cr on cr.id=c.id
inner join Projects pr ON pr.id = c.[project_id]
inner join Tiers ti ON ti.id = pr.tiers_id
inner join Persons pe ON pe.id = ti.id
inner join Users u ON u.id = cr.loanofficer_id
inner join Districts d ON d.id = ti.district_id
inner join Branchinfo b ON b.branch_id = ti.branch_id
left join Branches b2 ON b2.id = ti.branch_id
left join CollateralsLinkContracts cl on cl.contract_id = cr.id
left join LinkGuarantorCredit gr on gr.contract_id = cr.id 
where ce.contract_id=@loanID 
order by ce.event_date desc

