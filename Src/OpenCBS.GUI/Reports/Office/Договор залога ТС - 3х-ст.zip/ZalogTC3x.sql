﻿--declare @contract_id INT=847
	
	DECLARE @start_date DATETIME
	SELECT @start_date = START_DATE
	FROM   dbo.Contracts
	WHERE  id = @contract_id
	
	SELECT 
	co.contract_code,
	co.contract_code+'/Z' as zalog_code,		
	dbo.DateToString(co.close_date)+N' года' as close_date,
	dbo.DateToString(co.start_date)+N' года' AS START_DATE,
	ISNULL(pe.last_name,'') +' '+ ISNULL(LEFT(pe.first_name,1),'')+'. '+ISNULL(LEFT(pe.father_name,1),'')+'.' AS client_short_name,
	ISNULL(pe.last_name, '') + ' ' + ISNULL(pe.first_name, '') + ' ' +ISNULL(pe.father_name, '') AS client_name,
	pe.identification_data,
	ISNULL(u.last_name, '') +' '+ ISNULL(u.first_name, '') loan_officer,
	b.agreement AS agreement,
	dbo.DateToString(b.date_of_agreement)+N' года' AS date_of_agreement,
	d.name AS cl_district,
	ti.city AS cl_city,
	convert(nvarchar(10),pe.birth_date,104) as birth_date,
	ti.[address] AS cl_adress,
	ti.home_phone AS home_phone,
	ti.personal_phone AS personal_phone,
	ISNULL(mtg.last_name, '')+' '+ISNULL(mtg.first_name, '')+' '+ ISNULL(mtg.father_name, '') mortgager,
	ISNULL(mtg.last_name, '')+' '+ISNULL(LEFT(mtg.first_name,1), '')+'.'+ ISNULL(LEFT(mtg.father_name,1), '')+'.' mortgager_short,
	mtg_ti.[address] mtg_address,
        convert(nvarchar(10),mtg.birth_date,104) as mtg_birth_date,
	mtg_ti.city mtg_city,
	mtg.identification_data mtg_identification_data,
	mtg_di.[name] mtg_district,
	cast(cr.amount as numeric(10,2)) AS amount,
	dbo.Stringify('D[ru]', ISNULL(cr.amount, 0)) AS amount_words,
	cr.nb_of_installment,
	dbo.Stringify('D[ru]', ISNULL(cr.nb_of_installment, 0)) AS nb_of_ins_words,
	cast(cr.interest_rate as numeric(10,2)) as interest_rate,
	cast(cr.interest_rate*100 as numeric(10,2)) AS IR_monthly,
    dbo.Stringify('D[ru]', ISNULL(ROUND(cr.interest_rate*100,0,1),0)) AS i_r_words_decimal,
    dbo.Stringify('D[ru]', ISNULL((cr.interest_rate*100-ROUND(cr.interest_rate*100,0,1))*100,0)) AS i_r_words_cents,
	dbo.Stringify('D%[ru]', ISNULL(cr.interest_rate * 100, 0)) AS i_r_words,
	cast(cr.interest_rate * 1200 as numeric(10,2)) AS ir_12,
	cola.col_amount,
	dbo.Stringify('D[ru]', ISNULL(cola.col_amount, 0)) AS col_amount_words, 
	ISNULL(co.loan_purpose, '') AS purpose_of_loan,
	pkg.name AS package_name,
	dbo.Stringify('D%[ru]', ISNULL(cr.interest_rate * 1200, 0)) AS ir12_words,
	b.city AS br_city,
	b.director AS br_director,
    b.director_nominative as director_nominative,
	br.[address] branch_address,
	b.tin b_tin,
	

	
	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Марка' ) AS Collateral_mark,

	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Год выпуска' ) AS Collateral_issue_year,
	

(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Кузов №' ) AS Collateral_body,
	
	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Цвет' ) AS Collateral_color,
	
	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Двигатель №' ) AS Collateral_engine,

        (Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Объем двигателя' ) AS Collateral_engine_volume,
	
	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Гос. регистрационный номер' ) AS Collateral_number,

	
	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Описание' ) AS Collateral_description,
	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Адрес' ) AS Collateral_address,
	
	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Сумма' ) AS Collateral_amount,

		
	(Select cpv.value 
	from CollateralsLinkContracts clc 
	LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id
	LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	where clc.contract_id=@contract_id and cp.name=N'Основание' ) AS Collateral_foundation

		
	FROM   Credit cr
	INNER JOIN Contracts co ON  co.id = cr.id
	INNER JOIN Packages pkg ON  pkg.id = cr.package_id
	INNER JOIN Projects pr ON  pr.id = co.[project_id]
	INNER JOIN Tiers ti ON  ti.id = pr.tiers_id
	INNER JOIN Persons pe ON  pe.id = ti.id
	INNER JOIN Users u ON  u.id = cr.loanofficer_id
	LEFT JOIN Branches br ON  ti.branch_id = br.id
	LEFT JOIN Districts d ON  d.id = ti.district_id
	LEFT JOIN Branchinfo b ON  b.branch_id = ti.branch_id
	------------------------------------------------------------ 	--LEFT JOIN CollateralsLinkContracts clc ON clc.contract_id=co.id	--LEFT JOIN CollateralPropertyValues cpv ON cpv.contract_collateral_id=clc.id	--LEFT JOIN CollateralProperties cp ON cp.id=cpv.property_id
	LEFT JOIN (SELECT TOP 1 clc.contract_id, cpv.[value] FROM CollateralsLinkContracts clc
	          INNER JOIN CollateralPropertyValues cpv ON  clc.id = cpv.contract_collateral_id
	          INNER JOIN CollateralProperties cp ON  cpv.property_id = cp.id AND cp.[type_id] = 5 AND clc.contract_id = @contract_id) col ON  co.id = col.contract_id
	
	LEFT JOIN Tiers mtg_ti ON  col.[value] = mtg_ti.id
	LEFT JOIN Persons mtg ON  mtg_ti.id = mtg.id
	LEFT JOIN Districts mtg_di ON  mtg_ti.district_id = mtg_di.id
	
	LEFT JOIN (SELECT clc.contract_id, SUM(CAST(cpv.[value] AS DECIMAL)) col_amount FROM CollateralsLinkContracts clc
	          INNER JOIN CollateralPropertyValues cpv ON  clc.id = cpv.contract_collateral_id
	          INNER JOIN CollateralProperties cp ON  cpv.property_id = cp.id AND cp.NAME = N'Сумма'
		      GROUP BY clc.contract_id) cola ON  co.id = cola.contract_id	   
	WHERE  cr.id = @contract_id
