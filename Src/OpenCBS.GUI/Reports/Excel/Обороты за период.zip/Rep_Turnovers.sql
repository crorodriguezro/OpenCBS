--declare @disbursed_in INT=0, @display_in INT=1, @from DATETIME='03-01-2014',  @to DATETIME='03-31-2014', @branch_id INT=0;

WITH batch_report AS
(
SELECT null [date]
, cl.name
, null code
, null start_balance
, null income
, comis.fees comissions
, null penalties
, null interest
, null normal_principal
, null late_principal
, null end_balance
FROM dbo.Contracts AS Cont
LEFT JOIN dbo.Projects AS Pr ON Cont.project_id = Pr.id
LEFT JOIN dbo.Tiers Tr on Tr.id=Pr.tiers_id
LEFT JOIN dbo.Clients cl on cl.id=Tr.id
inner JOIN (
		SELECT ce.contract_id, SUM(de.fee) fees
		FROM dbo.LoanEntryFeeEvents de
		LEFT JOIN dbo.ContractEvents ce ON ce.id=de.id
		WHERE ce.is_deleted=0
		AND CAST(ce.event_date as DATE) >= CAST(@from as date)
		AND CAST(ce.event_date as DATE) <= CAST(@to as date)
		GROUP BY ce.contract_id
) AS comis ON comis.contract_id=Cont.id
WHERE Tr.branch_id = @branch_id OR @branch_id = 0

UNION ALL

SELECT amounts.[date]
, cl.name
, amounts.code
, amounts.start_balance
, amounts.income
, null comissions
, amounts.penalties
, amounts.interest
, amounts.normal_principal
, amounts.late_principal
, amounts.end_balance
FROM (
		SELECT ce.event_date [date]
		, Pr.tiers_id
		, Cont.contract_code code
		, null start_balance
		, null income
		, null comissions
		, ISNULL(re_children.penalty, 0) penalties
		, ISNULL(re_children.interest, 0) interest
		, ISNULL(re_children.normal_principal, 0) normal_principal
		, ISNULL(re_children.late_principal, 0) late_principal
		, null end_balance
		FROM dbo.RepaymentEvents re
		LEFT JOIN dbo.ContractEvents ce ON ce.id=re.id
		LEFT JOIN dbo.Contracts AS Cont ON Cont.id = ce.contract_id
		LEFT JOIN dbo.Projects AS Pr ON Cont.project_id = Pr.id
		LEFT JOIN dbo.Tiers AS Tr ON Tr.id = Pr.tiers_id
		LEFT JOIN dbo.Clients AS Cl ON Cl.id = Tr.id
		LEFT JOIN
		(
			SELECT e.parent_id, 
				SUM(re.principal) normal_principal,
				0 late_principal,
				SUM(re.interests) interest,
				SUM(re.penalties) penalty
			FROM dbo.ContractEvents e
			INNER JOIN dbo.RepaymentEvents re ON e.id = re.id
			WHERE NOT e.parent_id IS NULL and re.past_due_days=0
			AND CAST(e.event_date as DATE) >= CAST(@from as date)
			AND CAST(e.event_date as DATE) <= CAST(@to as date)
			GROUP BY e.parent_id
			
			union All
			
			SELECT e.parent_id, 
				0 normal_principal,
				SUM(re.principal) late_principal,
				SUM(re.interests) interest,
				SUM(re.penalties) penalty
			FROM dbo.ContractEvents e
			INNER JOIN dbo.RepaymentEvents re ON e.id = re.id
			WHERE NOT e.parent_id IS NULL and re.past_due_days>0
			AND CAST(e.event_date as DATE) >= CAST(@from as date)
			AND CAST(e.event_date as DATE) <= CAST(@to as date)
			GROUP BY e.parent_id
			
			union All
			
			SELECT e.id parent_id,
				case when re.past_due_days=0
					then re.principal 
					else 0 
					end as normal_principal,
				case when re.past_due_days>0
					then re.principal
					else 0
					end as late_principal,
				re.interests interest,
				re.penalties penalty
			FROM ContractEvents e
			inner join RepaymentEvents re on e.id=re.id
			left join Contracts c on e.contract_id=c.id
			where e.parent_id IS NULL
			AND CAST(e.event_date as DATE) >= CAST(@from as date)
			AND CAST(e.event_date as DATE) <= CAST(@to as date)
		) re_children ON re_children.parent_id = re.id
		WHERE ce.is_deleted=0 and ce.parent_id IS NULL
		AND CAST(ce.event_date as DATE) >= CAST(@from as date)
		AND CAST(ce.event_date as DATE) <= CAST(@to as date)
		
		UNION ALL
		
		SELECT se.creation_date [date]
		, sc.tiers_id
		, sc.code code
		, null start_balance
		, ISNULL(se.amount,0) AS income
		, null comissions
		, null penalties
		, null interest
		, null normal_principal
		, null late_principal
		, null end_balance
		FROM SavingEvents se
		LEFT JOIN dbo.SavingContracts sc ON sc.id=se.contract_id
		WHERE se.deleted = 0 
		AND se.is_fired = 1 
		AND CAST(se.creation_date as DATE) >= CAST(@from as date)
		AND CAST(se.creation_date as DATE) <= CAST(@to as date)
		AND se.code IN ('SVIE','SVDE')
		
		union all
		
		SELECT null [date]
		, sc.tiers_id
		, sc.code code
		, ISNULL(deposit_from.amount,0)-ISNULL(withdraw_from.amount,0) start_balance
		, null income
		, null comissions
		, null penalties
		, null interest
		, null normal_principal
		, null late_principal
		, ISNULL(deposit_to.amount,0)-ISNULL(withdraw_to.amount,0) end_balance
		FROM dbo.SavingContracts sc
		LEFT JOIN (
				SELECT SUM(ISNULL(se.amount,0)) AS amount, se.contract_id
				FROM SavingEvents se
				WHERE se.deleted = 0 
				AND se.is_fired = 1 
				AND CAST(se.creation_date as DATE) < CAST(@from as date)
				AND se.code IN ('SVIE','SVDE')
				GROUP BY se.contract_id
		) AS deposit_from ON deposit_from.contract_id=sc.id
		LEFT JOIN (			 
				SELECT SUM(ISNULL(se.amount,0)) amount, se.contract_id
				FROM SavingEvents se
				WHERE se.deleted = 0 
				AND se.is_fired = 1 
				AND CAST(se.creation_date as DATE) < CAST(@from as DATE)
				AND se.code IN ('SVWE')
				GROUP BY se.contract_id
		) AS withdraw_from ON withdraw_from.contract_id=sc.id
		LEFT JOIN (
				SELECT SUM(ISNULL(se.amount,0)) AS amount, se.contract_id
				FROM SavingEvents se
				WHERE se.deleted = 0 
				AND se.is_fired = 1 
				AND CAST(se.creation_date as DATE) <= CAST(@to as date)
				AND se.code IN ('SVIE','SVDE')
				GROUP BY se.contract_id
		) AS deposit_to ON deposit_to.contract_id=sc.id
		LEFT JOIN (			 
				SELECT SUM(ISNULL(se.amount,0)) amount, se.contract_id
				FROM SavingEvents se
				WHERE se.deleted = 0 
				AND se.is_fired = 1 
				AND CAST(se.creation_date as DATE) <= CAST(@to as DATE)
				AND se.code IN ('SVWE')
				GROUP BY se.contract_id
		) AS withdraw_to ON withdraw_to.contract_id=sc.id
) AS amounts
LEFT JOIN dbo.Clients cl on cl.id=amounts.tiers_id
LEFT JOIN dbo.Tiers Tr on Tr.id=amounts.tiers_id
WHERE Tr.branch_id = @branch_id OR @branch_id = 0
	)
	SELECT *
	FROM batch_report
	ORDER by [date], name
	
	--UNION ALL
	
	--SELECT 'TOTAL'
	--,NULL,NULL,NULL,NULL
	--,SUM(loan_amount)
	--,NULL,NULL
	--,SUM(olb)
	--,NULL,NULL,NULL,NULL,NULL,NULL
	--,SUM(late_principal)
	--,SUM(late_interest)
	--,SUM(penalties_accrued)
	--,SUM(penalties_paid)
	--,NULL
	--,SUM(llp_amount)
	--,NULL,NULL,NULL,NULL,NULL
	--FROM batch_report

