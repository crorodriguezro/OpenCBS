--declare @BookingId int =10
select 
b.Amount amount,
p.first_name+' '+p.last_name client,
b.DebitAccount debitAccount,
b.CreditAccount creditAccount,
convert(nvarchar(10), b.Date, 104) date,
b.Description  Description,
p.identification_data pasport,
dbo.Stringify('D[en]', floor(b.Amount))+' $, '+ dbo.Stringify('D[en]', round((b.Amount-FLOOR(b.Amount))*100,0))+' cent ' sumInWords
from Booking b
left join Persons p on p.id = b.ClientId
where b.Id=@BookingId