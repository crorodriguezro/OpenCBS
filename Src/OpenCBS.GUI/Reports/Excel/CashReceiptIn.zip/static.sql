--declare @BookingId int =352089
select 
b.Amount amount,
case when b.ClientId=0 then (s.LastName+' '+s.FirstName+' '+s.PatronymicName) else  p.first_name+' '+p.last_name end client,
b.DebitAccount debitAccount,
b.CreditAccount creditAccount,
convert(nvarchar(10), b.Date, 104) date,
b.Description  Description,
case when b.ClientId=0 then '№ '+s.DocumentId else '№ '+p.identification_data end pasport,
dbo.Stringify('D[en]', floor(b.Amount))+' $, '+ dbo.Stringify('D[en]', round((b.Amount-FLOOR(b.Amount))*100,0))+' cent ' sumInWords
from Booking b
left join Persons p on p.id = b.ClientId
left join Staff s on s.AdvanceAccountNumber=b.DebitAccount
where b.Id=@BookingId

