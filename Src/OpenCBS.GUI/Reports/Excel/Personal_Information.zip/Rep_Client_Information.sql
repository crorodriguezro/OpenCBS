	DECLARE @advanced_fields TABLE
	(
		id INT IDENTITY(1,1) NOT NULL
		, field_id int	
	)
	INSERT INTO @advanced_fields SELECT id FROM customfields where owner = 'Person' and [type] != 'Boolean'

	DECLARE @custom1 int = (select field_id FROM @advanced_fields WHERE id = 1)
	DECLARE @custom2 int = (select field_id FROM @advanced_fields WHERE id = 2)
	DECLARE @custom3 int = (select field_id FROM @advanced_fields WHERE id = 3)
	DECLARE @custom4 int = (select field_id FROM @advanced_fields WHERE id = 4)
	DECLARE @custom5 int = (select field_id FROM @advanced_fields WHERE id = 5)
	DECLARE @custom6 int = (select field_id FROM @advanced_fields WHERE id = 6)
	DECLARE @custom7 int = (select field_id FROM @advanced_fields WHERE id = 7)
	DECLARE @custom8 int = (select field_id FROM @advanced_fields WHERE id = 8)
	DECLARE @custom9 int = (select field_id FROM @advanced_fields WHERE id = 9)
	DECLARE @custom10 int = (select field_id FROM @advanced_fields WHERE id = 10)
	
    DECLARE @active_loans TABLE
    (
        id INT NOT NULL
        , late_days INT NOT NULL
        , olb MONEY
        , amount MONEY
    )
    INSERT INTO @active_loans
    SELECT id, late_days, olb, amount
    FROM dbo.ActiveLoans(@from, @branch_id)
    
	SELECT DISTINCT  
	  Tr.id 
	, COALESCE(Corporates.Name, Gr.name, ISNULL(Pers.first_name, ''))  AS [client_first_name]
	,ISNULL(Pers.last_name, '') AS [client_last_name]
	, Tr.client_type_code AS [type]
	, Dis.name AS [district]
	, ISNULL(Tr.personal_phone, '-') AS [pers_phone]
	, ISNULL(Tr.secondary_personal_phone, '-') AS [s_pers_phone]
	, COALESCE(EcAc.name, CorporateActivities.name, '-') AS [activity]
	, ISNULL(Pers.sex, '-') AS sex, Cont.contract_code AS [contract_code]
	, Cont.start_date
	, Cont.close_date 
	, CAST(al.amount * dbo.GetXR(Pack.currency_id, @display_in, @from) AS MONEY) AS [loan_amount]
	, CAST(al.olb * dbo.GetXR(Pack.currency_id, @display_in, @from) AS MONEY) AS [olb]
	, Tr.loan_cycle
	, Us.first_name + SPACE(1) + Us.last_name AS [loan_admin]
	, Pack.name AS [product_name], Pack.code AS [product_code]
	, ISNULL(LiGrCr.guarantor, '-') AS [guarantor]
	, ISNULL(CAST(LiGrCr.guarantee_amount * dbo.GetXR(Pack.currency_id, @display_in, @from) AS MONEY), '-') AS [g_amount]
	, ISNULL(LiClCr.name, '-') AS [collateral]
	, ISNULL(CAST(LiClCr.collateral_amount * dbo.GetXR(Pack.currency_id, @display_in, @from) AS MONEY), '-') AS [c_amount]
	, Cr.grace_period
	, Cr.nb_of_installment AS [maturity]
	, Cr.interest_rate
	, al.late_days
	, COALESCE(nsg.name, LoShAm.group_name, '-') AS [group_name]
	, ISNULL(CAST(LoShAm.loan_share * dbo.GetXR(Pack.currency_id, @display_in, @from) AS MONEY), '-') AS [loan_share]
	, Br.code AS branch_name
	, ISNULL(dbo.GetAdvancedFieldValue(Tr.id, @custom1), '-') AS custom#1
	, ISNULL(dbo.GetAdvancedFieldValue(Tr.id, @custom2), '-') AS custom#2
	, ISNULL(dbo.GetAdvancedFieldValue(Tr.id, @custom3), '-') AS custom#3
	, ISNULL(dbo.GetAdvancedFieldValue(Tr.id, @custom4), '-') AS custom#4
	, ISNULL(dbo.GetAdvancedFieldValue(Tr.id, @custom5), '-') AS custom#5
	, ISNULL(dbo.GetAdvancedFieldValue(Tr.id, @custom6), '-') AS custom#6
	, ISNULL(dbo.GetAdvancedFieldValue(Tr.id, @custom7), '-') AS custom#7
	, ISNULL(dbo.GetAdvancedFieldValue(Tr.id, @custom8), '-') AS custom#8
	, ISNULL(dbo.GetAdvancedFieldValue(Tr.id, @custom9), '-') AS custom#9
	, ISNULL(dbo.GetAdvancedFieldValue(Tr.id, @custom10), '-') AS custom#10
	FROM @active_loans AS al
	INNER JOIN dbo.Contracts AS Cont ON Cont.id = al.id
	INNER JOIN dbo.Credit AS Cr ON Cr.id = Cont.id
	INNER JOIN dbo.Packages AS Pack ON Cr.package_id = Pack.id
	INNER JOIN dbo.Users AS Us ON Us.id = Cr.loanofficer_id
	LEFT JOIN dbo.Projects AS Pr ON Cont.project_id = Pr.id
	LEFT JOIN dbo.Tiers AS Tr ON Tr.id = Pr.tiers_id
	LEFT JOIN dbo.Branches Br ON Br.id = Tr.branch_id
	LEFT JOIN dbo.Districts AS Dis ON Dis.id = Tr.district_id
	LEFT JOIN dbo.Groups AS Gr ON Gr.id = Tr.id
	LEFT JOIN dbo.Persons AS Pers ON Pers.id = Tr.id
	LEFT JOIN dbo.EconomicActivities AS EcAc ON EcAc.id = Pers.activity_id
	LEFT JOIN 
	(
		SELECT DISTINCT LiGrCr.contract_id
		, Pr.first_name + SPACE(1) + Pr.last_name AS [guarantor]
		, LiGrCr.guarantee_amount
		FROM LinkGuarantorCredit AS LiGrCr
		INNER JOIN Tiers AS Tr ON Tr.id = LiGrCr.tiers_id
		INNER JOIN Persons AS Pr ON Pr.id = Tr.id
	) AS LiGrCr ON LiGrCr.contract_id = Cont.id
	LEFT JOIN
	(
		SELECT 
		CASE WHEN ISNUMERIC(CollateralPropertyValues.value) = 1 
			 THEN CONVERT(MONEY, CollateralPropertyValues.value) 
			 ELSE 0 
		END AS collateral_amount
		, CollateralsLinkContracts.contract_id AS [contract_id]
		, CollateralProducts.name AS [name]
		FROM dbo.CollateralsLinkContracts 
		INNER JOIN dbo.CollateralPropertyValues ON CollateralsLinkContracts.id = CollateralPropertyValues.contract_collateral_id
		INNER JOIN dbo.CollateralProperties ON CollateralProperties.id = CollateralPropertyValues.property_id
		INNER JOIN dbo.CollateralProducts ON CollateralProperties.product_id = CollateralProducts.id
		WHERE CollateralProperties.name = 'Amount' AND CollateralProperties.[type_id] = 1
	) AS LiClCr ON LiClCr.contract_id = Cont.id	
	LEFT JOIN
	(
		SELECT LoShAm.contract_id, LoShAm.person_id, Gr.name AS [group_name], LoShAm.amount AS [loan_share]
		FROM LoanShareAmounts AS LoShAm
		LEFT JOIN Groups AS Gr ON Gr.id = LoShAm.group_id
	) AS LoShAm ON LoShAm.person_id = Pers.id
	LEFT JOIN Corporates ON Tr.id = Corporates.id
	LEFT JOIN dbo.EconomicActivities AS CorporateActivities ON CorporateActivities.id = Corporates.activity_id
	LEFT JOIN dbo.Villages nsg ON Cont.nsg_id = nsg.id
	WHERE (Pack.currency_id = @disbursed_in OR 0 = @disbursed_in) AND (Tr.branch_id = @branch_id OR @branch_id = 0)
	ORDER BY type DESC, district, client_first_name,client_last_name