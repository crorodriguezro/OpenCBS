
--declare @from datetime = '2014-12-10'
--declare @branch_id int = 0;
DECLARE @advanced_fields TABLE
(
	id INT IDENTITY(1,1) NOT NULL
	, field_id int	
)
INSERT INTO @advanced_fields SELECT id FROM customfields where owner = 'Person' and [type] != 'Boolean'

DECLARE @custom1 int = (select field_id FROM @advanced_fields WHERE id = 1)
DECLARE @custom2 int = (select field_id FROM @advanced_fields WHERE id = 2)
DECLARE @custom3 int = (select field_id FROM @advanced_fields WHERE id = 3)
DECLARE @custom4 int = (select field_id FROM @advanced_fields WHERE id = 4)
DECLARE @custom5 int = (select field_id FROM @advanced_fields WHERE id = 5)
DECLARE @custom6 int = (select field_id FROM @advanced_fields WHERE id = 6)
DECLARE @custom7 int = (select field_id FROM @advanced_fields WHERE id = 7)
DECLARE @custom8 int = (select field_id FROM @advanced_fields WHERE id = 8)
DECLARE @custom9 int = (select field_id FROM @advanced_fields WHERE id = 9)
DECLARE @custom10 int = (select field_id FROM @advanced_fields WHERE id = 10);
	
with temp as

(
	select
		p.id,
		isnull(v.name, '') village_name
	from
		dbo.Persons p
	left join
		dbo.VillagesPersons vp on vp.person_id = p.id
	left join
		dbo.Villages v on v.id = vp.village_id 
),
people_with_village_bank_names as
(
	select 
		a.id,
		village_name =
			stuff((
				select 
					', ' + village_name
				from 
					temp b
				where
					b.id = a.id
				for xml path('')
			), 1, 1, '')
	from 
		temp a
	group by
		a.id
)

select distinct
	pvb.id,
	p.first_name,
	p.last_name,
	Tiers.client_type_code AS type,
	Districts.name as district_name,
	Tiers.personal_phone as first_personal_phone,
	[Tiers].[secondary_personal_phone] AS sec_pers_phone,
	 EA.name as activity,
    p.sex as sex,
	pvb.village_name,
	[Branches].[code] AS branch_name
	, ISNULL(dbo.GetAdvancedFieldValue([Tiers].id, @custom1), '-') AS custom#1
	, ISNULL(dbo.GetAdvancedFieldValue([Tiers].id, @custom2), '-') AS custom#2
	, ISNULL(dbo.GetAdvancedFieldValue([Tiers].id, @custom3), '-') AS custom#3
	, ISNULL(dbo.GetAdvancedFieldValue([Tiers].id, @custom4), '-') AS custom#4
	, ISNULL(dbo.GetAdvancedFieldValue([Tiers].id, @custom5), '-') AS custom#5
	, ISNULL(dbo.GetAdvancedFieldValue([Tiers].id, @custom6), '-') AS custom#6
	, ISNULL(dbo.GetAdvancedFieldValue([Tiers].id, @custom7), '-') AS custom#7
	, ISNULL(dbo.GetAdvancedFieldValue([Tiers].id, @custom8), '-') AS custom#8
	, ISNULL(dbo.GetAdvancedFieldValue([Tiers].id, @custom9), '-') AS custom#9
	, ISNULL(dbo.GetAdvancedFieldValue([Tiers].id, @custom10), '-') AS custom#10
from
	people_with_village_bank_names pvb
    left join
	dbo.Persons p on p.id = pvb.id
	left join
	[dbo].[Tiers] ON p.id = [Tiers].[id] 
	LEFT JOIN
	[dbo].[Districts] ON [Districts].[id] = [Tiers].[district_id] LEFT JOIN
	[dbo].[Branches] ON [Branches].[id] = [Tiers].[branch_id] LEFT JOIN
	EconomicActivities EA ON [EA].[id] = p.[activity_id] LEFT JOIN
	[dbo].[VillagesPersons] VP ON p.id = VP.person_id left JOIN
	 [dbo].[PersonGroupBelonging] PGB ON p.[id] = PGB.person_id LEFT JOIN
    [dbo].[Groups] ON [Groups].[id] = PGB.group_id LEFT JOIN
    [dbo].[Villages] ON [Villages].[id] = VP.[village_id]  inner join
	(
        SELECT [Persons].[id]
        FROM [dbo].[Persons] 
            EXCEPT --(����� ����������� 2-�� �������)
        SELECT [ActiveClients].[id] 
        FROM ActiveClients(@from,@branch_id)
    ) Temp ON [Temp].[id] = p.id
	 where Tiers.id = @branch_id OR @branch_id = 0
	ORDER BY p.last_name