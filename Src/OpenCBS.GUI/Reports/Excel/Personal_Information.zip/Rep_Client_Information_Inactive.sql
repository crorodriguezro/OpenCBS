DECLARE @advanced_fields TABLE
(
	id INT IDENTITY(1,1) NOT NULL
	,name NVARCHAR(255)	
)
	
INSERT INTO @advanced_fields SELECT name FROM dbo.AdvancedFields WHERE entity_id = 1

	DECLARE @custom1 NVARCHAR(255)
	DECLARE @custom2 NVARCHAR(255)
	DECLARE @custom3 NVARCHAR(255)
	DECLARE @custom4 NVARCHAR(255)
	DECLARE @custom5 NVARCHAR(255)
	DECLARE @custom6 NVARCHAR(255)
	DECLARE @custom7 NVARCHAR(255)
	DECLARE @custom8 NVARCHAR(255)
	DECLARE @custom9 NVARCHAR(255)
	DECLARE @custom10 NVARCHAR(255)

	SELECT @custom1 = name FROM @advanced_fields WHERE id = 1
	SELECT @custom2 = name FROM @advanced_fields WHERE id = 2
	SELECT @custom3 = name FROM @advanced_fields WHERE id = 3
	SELECT @custom4 = name FROM @advanced_fields WHERE id = 4
	SELECT @custom5 = name FROM @advanced_fields WHERE id = 5
	SELECT @custom6 = name FROM @advanced_fields WHERE id = 6
	SELECT @custom7 = name FROM @advanced_fields WHERE id = 7
	SELECT @custom8 = name FROM @advanced_fields WHERE id = 8
	SELECT @custom9 = name FROM @advanced_fields WHERE id = 9
	SELECT @custom10 = name FROM @advanced_fields WHERE id = 10


SELECT 
     [Tiers].[id]
    ,[Persons].[first_name] AS client_first_name
    ,[Persons].[lASt_name] AS client_last_name
    ,[Tiers].[client_type_code] AS type
    ,[Districts].[name] AS district_name
    ,[Tiers].[personal_phone] AS first_pers_phone
    ,[Tiers].[secondary_personal_phone] AS sec_pers_phone
    ,EA.name as activity
    ,[Persons].[sex]
	,COALESCE(Villages.name, Groups.name, '-') AS group_name
    ,[Branches].[code] AS branch_name
    ,ISNULL(dbo.GetAdvancedFieldValue(Tiers.id, 'C', @custom1), 'Contact us at contact@opencbs.com to display your custom fields') AS custom#1
   
FROM 
    [dbo].[Persons] LEFT JOIN 
    [dbo].[Tiers] ON [Persons].[id] = [Tiers].[id] LEFT JOIN 
    [dbo].[Districts] ON [Districts].[id] = [Tiers].[district_id] LEFT JOIN 
    [dbo].[Branches] ON [Branches].[id] = [Tiers].[branch_id] LEFT JOIN
    EconomicActivities EA ON [EA].[id] = [Persons].[activity_id] LEFT JOIN
    [dbo].[VillagesPersons] VP ON [Persons].id = VP.person_id LEFT JOIN
    [dbo].[PersonGroupBelonging] PGB ON [Persons].[id] = PGB.person_id LEFT JOIN
    [dbo].[Groups] ON [Groups].[id] = PGB.group_id LEFT JOIN
    [dbo].[Villages] ON [Villages].[id] = VP.[village_id] INNER JOIN
	(
        SELECT [Persons].[id]
        FROM [dbo].[Persons] 
            EXCEPT --(����� ����������� 2-�� �������)
        SELECT [ActiveClients].[id] 
        FROM ActiveClients(@from,@branch_id)
    ) Temp ON [Temp].[id] = [Persons].[id]
    
    WHERE [Tiers].[branch_id] = @branch_id OR @branch_id = 0