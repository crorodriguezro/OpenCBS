--declare @from datetime='12-17-2014', @to datetime='12-17-2014'
select account Code
	                , label Label
	                , case when is_debit=1
		                then isnull(b.startDebit,0)-isnull(b.startCredit,0)
		                else 0
		                end StartDebit
	                , case when is_debit=1
		                then 0
		                else isnull(b.startCredit,0)-isnull(b.startDebit,0)
		                end StartCredit
	                , case when is_debit=1
		                then ISNULL(b.debit,0)
		                else ISNULL(b.credit,0)
		                end Debit
	                , case when is_debit=1
		                then ISNULL(b.credit,0)
		                else ISNULL(b.debit,0)
		                end Credit
	                , case when is_debit=1
		                then isnull(b.endDebit,0)-isnull(b.endCredit,0)
		                else 0
		                end EndDebit
	                , case when is_debit=1
		                then 0
		                else isnull(b.endCredit,0)-isnull(b.endDebit,0)
		                end EndCredit
                from (
                select t.parent account
	                , sum(isnull(startDebit.amount,0)) startDebit
	                , sum(isnull(startCredit.amount,0)) startCredit
	                , sum(isnull(debit.amount,0)) debit
	                , sum(isnull(credit.amount,0)) credit
	                , sum(isnull(endDebit.amount,0)) endDebit
	                , sum(isnull(endCredit.amount,0)) endCredit 
                from (
	                select a2.account_number parent, a1.account_number child from Accounts a1, Accounts a2
	                where a1.lft between a2.lft and a2.rgt and a2.is_balance_account = 1
                ) t
                left join (
                    select CreditAccount account, sum(isnull(amount,0)) amount
                    from Booking
                    where cast(Date as date)<CAST(@from as date)
                    group by CreditAccount
                ) startCredit on startCredit.account=t.child
                left join (
                    select DebitAccount account, sum(isnull(amount,0)) amount
                    from Booking
                    where cast(Date as date)<CAST(@from as date)
                    group by DebitAccount
                ) startDebit on startDebit.account=t.child
                left join (
                    select CreditAccount account, sum(isnull(amount,0)) amount
                    from Booking
                    where cast(Date as date)<=CAST(@to as date)
                    and cast(Date as date)>=CAST(@from as date)
                    group by CreditAccount
                ) credit on credit.account=t.child
                left join (
                    select DebitAccount account, sum(isnull(amount,0)) amount
                    from Booking
                    where cast(Date as date)<=CAST(@to as date)
                    and cast(Date as date)>=CAST(@from as date)
                    group by DebitAccount
                ) debit on debit.account=t.child
                left join (
	                select DebitAccount account, sum(isnull(amount,0)) amount
	                from Booking
	                where cast(Date as date)<=CAST(@to as date)
	                group by DebitAccount 
                ) endDebit on endDebit.account=t.child
                left join (
	                select CreditAccount account, sum(isnull(amount,0)) amount
	                from Booking 
	                where cast(Date as date)<=CAST(@to as date)
	                group by CreditAccount
                ) endCredit on endCredit.account=t.child
                group by t.parent
                ) b
                left join Accounts a on a.account_number=b.account
                left join Categories cat on cat.Id = a.id_category