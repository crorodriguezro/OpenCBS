--declare @from datetime='06-01-2014', @to datetime='06-30-2014'
select account_number
, label
, case when cha.debit_plus=1
	then isnull(debit_from.amount,0)-isnull(credit_from.amount,0)
	else 0
	end debit_from
, case when cha.debit_plus=1
	then 0
	else isnull(debit_from.amount,0)-isnull(credit_from.amount,0)
	end credit_from
, case when cha.debit_plus=1
	then ISNULL(debit.amount,0)
	else ISNULL(credit.amount,0)
	end debit
, case when cha.debit_plus=1
	then ISNULL(credit.amount,0)
	else ISNULL(debit.amount,0)
	end credit
, case when cha.debit_plus=1
	then isnull(debit_to.amount,0)-isnull(credit_to.amount,0)
	else 0
	end debit_to
, case when cha.debit_plus=1
	then 0
	else isnull(debit_to.amount,0)-isnull(credit_to.amount,0)
	end credit_to
from ChartOfAccounts cha
left join (
	select cha.id, isnull(sum(amount),0) amount
	from ChartOfAccounts cha
	left join Booking b on b.CreditAccountId=cha.id
	where cast(b.Date as date)<CAST(@from as date)
	group by cha.id
) credit_from on credit_from.id=cha.id
left join (
	select cha.id, isnull(sum(amount),0) amount
	from ChartOfAccounts cha
	left join Booking b on b.DebitAccountId=cha.id
	where cast(b.Date as date)<CAST(@from as date)
	group by cha.id
) debit_from on debit_from.id=cha.id
left join (
	select cha.id, isnull(sum(amount),0) amount
	from ChartOfAccounts cha
	left join Booking b on b.CreditAccountId=cha.id
	where cast(b.Date as date)<=CAST(@to as date)
	and cast(b.Date as date)>=CAST(@from as date)
	group by cha.id
) credit on credit.id=cha.id
left join (
	select cha.id, isnull(sum(amount),0) amount
	from ChartOfAccounts cha
	left join Booking b on b.DebitAccountId=cha.id
	where cast(b.Date as date)<=CAST(@to as date)
	and cast(b.Date as date)>=CAST(@from as date)
	group by cha.id
) debit on debit.id=cha.id
left join (
	select cha.id, isnull(sum(amount),0) amount
	from ChartOfAccounts cha
	left join Booking b on b.CreditAccountId=cha.id
	where cast(b.Date as date)<=CAST(@to as date)
	group by cha.id
) credit_to on credit_to.id=cha.id
left join (
	select cha.id, isnull(sum(amount),0) amount
	from ChartOfAccounts cha
	left join Booking b on b.DebitAccountId=cha.id
	where cast(b.Date as date)<=CAST(@to as date)
	group by cha.id
) debit_to on debit_to.id=cha.id