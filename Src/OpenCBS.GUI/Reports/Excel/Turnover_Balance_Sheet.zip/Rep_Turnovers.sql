--declare @from datetime='06-01-2014', @to datetime='06-30-2014'
select account_number Code
, label Label
, case when is_debit=1
    then isnull(debit_from.amount,0)-isnull(credit_from.amount,0)
    else 0
    end StartDebit
, case when is_debit=1
    then 0
    else isnull(debit_from.amount,0)-isnull(credit_from.amount,0)
    end StartCredit
, case when is_debit=1
    then ISNULL(debit.amount,0)
    else ISNULL(credit.amount,0)
    end Debit
, case when is_debit=1
    then ISNULL(credit.amount,0)
    else ISNULL(debit.amount,0)
    end Credit
, case when is_debit=1
    then isnull(debit_to.amount,0)-isnull(credit_to.amount,0)
    else 0
    end EndDebit
, case when is_debit=1
    then 0
    else isnull(debit_to.amount,0)-isnull(credit_to.amount,0)
    end EndCredit
from Accounts a
left join (
    select CreditAccount account, isnull(sum(amount),0) amount
    from Booking
    where cast(Date as date)<CAST(@from as date)
    group by CreditAccount
) credit_from on credit_from.account=a.account_number
left join (
    select DebitAccount account, isnull(sum(amount),0) amount
    from Booking
    where cast(Date as date)<CAST(@from as date)
    group by DebitAccount
) debit_from on debit_from.account=a.account_number
left join (
    select CreditAccount account, isnull(sum(amount),0) amount
    from Booking
    where cast(Date as date)<=CAST(@to as date)
    and cast(Date as date)>=CAST(@from as date)
    group by CreditAccount
) credit on credit.account=a.account_number
left join (
    select DebitAccount account, isnull(sum(amount),0) amount
    from Booking
    where cast(Date as date)<=CAST(@to as date)
    and cast(Date as date)>=CAST(@from as date)
    group by DebitAccount
) debit on debit.account=a.account_number
left join (
    select CreditAccount account, isnull(sum(amount),0) amount
    from Booking 
    where cast(Date as date)<=CAST(@to as date)
    group by CreditAccount
) credit_to on credit_to.account=a.account_number
left join (
    select DebitAccount account, isnull(sum(amount),0) amount
    from Booking
    where cast(Date as date)<=CAST(@to as date)
    group by DebitAccount
) debit_to on debit_to.account=a.account_number