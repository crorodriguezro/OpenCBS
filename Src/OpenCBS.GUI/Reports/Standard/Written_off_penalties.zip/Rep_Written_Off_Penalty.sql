CREATE PROCEDURE dbo.Rep_Written_Off_Penalty
@from DATETIME, @to DATETIME, @disbursed_in INT, @display_in INT
AS BEGIN
	SELECT co.id as contract_id
	, co.contract_code
	, cl.name as client_name
	, d.name as district 
	, ce.event_date
	, dbo.GetOLB(co.id, ce.event_date) as olb
	, dbo.getLateDays(ce.event_date, co.id, re.installment_number) as late_days
	, dbo.GetXR(pack.currency_id, @display_in, ce.event_date) * re.calculated_penalties as due
	, dbo.GetXR(pack.currency_id, @display_in, ce.event_date) * re.penalties as paid
	, dbo.GetXR(pack.currency_id, @display_in, ce.event_date) * re.written_off_penalties as written_off
	, (CASE when ce.event_type = 'ROWO' THEN 1 ELSE 0 END) as type_of_group
	FROM RepaymentEvents re
	INNER JOIN ContractEvents ce ON ce.id = re.id
	INNER JOIN Contracts co ON co.id = ce.contract_id
	INNER JOIN Credit cr ON cr.id = co.id
	INNER JOIN Projects j ON j.id = co.project_id
	INNER JOIN Tiers t ON t.id = j.tiers_id
	LEFT JOIN Packages pack ON pack.id = cr.package_id
	LEFT JOIN Districts d ON d.id = t.district_id
	LEFT JOIN Clients cl ON cl.id = t.id
	WHERE ce.event_date BETWEEN @from AND @to 
		AND ce.is_deleted = 0
		AND re.written_off_penalties > 0
		AND (pack.currency_id = @disbursed_in OR 0 = @disbursed_in)
END

