CREATE PROCEDURE dbo.Rep_OLB_per_Client
	@date DATETIME,
	@disbursed_in INT,
	@display_in INT,
	@branch_id INT,
	@user_id INT,
	@subordinate_id INT
AS
BEGIN
	--DECLARE @date           DATETIME = GETDATE(),
	--        @disbursed_in   INT = 0,
	--        @display_in     INT = 1,
	--        @branch_id      INT = 1
	
	DECLARE @users TABLE
	        (id INT NOT NULL)
	
	INSERT INTO @users
	SELECT @user_id
	
	INSERT INTO @users
	SELECT subordinate_id
	FROM   dbo.UsersSubordinates
	WHERE  USER_ID = @user_id
	
	DECLARE @_date          DATETIME,
	        @_branch_id     INT,
	        @_disbursed_in  INT,
	        @_display_in    INT
	
	SET @_date = @date
	SET @_branch_id = @branch_id
	SET @_disbursed_in = @disbursed_in
	SET @_display_in = @display_in
	
	DECLARE @ContractEvents TABLE (contract_id INT, event_date DATETIME)
	INSERT INTO @ContractEvents 
	SELECT contract_id,
	                       MAX(event_date) event_date
	                FROM   dbo.ContractEvents
	                WHERE  is_deleted = 0
	                       AND event_type = 'LODE'
	                GROUP BY
	                       contract_id
	
	
	DECLARE @ActiveClients TABLE (id INT, contract_id INT, amount MONEY, olb MONEY,interest MONEY, initial_interest MONEY, paid_interest MONEY, late_days INT)
	INSERT INTO @ActiveClients
	 SELECT id,contract_id, amount, olb, interest, initial_interest, paid_interest, late_days
	  FROM dbo.ActiveClients_MC(@_date, @disbursed_in, @display_in, @branch_id) 
	  
	DECLARE @InstallmentSnapshot TABLE (contract_id INT, expected_date DATETIME)
	INSERT INTO @InstallmentSnapshot
					       SELECT contract_id,
	                       MAX(expected_date) AS expected_date
	                FROM   dbo.InstallmentSnapshot(@_date)
	                GROUP BY
	                       contract_id
	
	DECLARE @SolidaryGroup TABLE(contract_id INT, NAME NVARCHAR(MAX))
	INSERT INTO @SolidaryGroup
							SELECT lsa.contract_id,
	                        gr.name
							FROM   LoanShareAmounts lsa
								   INNER JOIN Groups gr
										ON  gr.id = lsa.group_id
							GROUP BY
								   lsa.contract_id,
								   gr.name
	DECLARE @NonSolidaryGroup TABLE(person_id INT, NAME NVARCHAR(MAX))		
	INSERT INTO 	@NonSolidaryGroup
					SELECT vp.person_id,
	                       MAX(v.name) AS NAME
	                FROM   Villages v
	                       INNER JOIN VillagesPersons vp
	                            ON  v.id = vp.village_id
	                            AND (vp.left_date > @_date OR vp.left_date IS NULL)
	                GROUP BY
	                       vp.person_id		
	
	SELECT COALESCE(Per.first_name, Corp.name) first_name,
	       COALESCE(Per.last_name, '-') last_name,
	       Per.identification_data,	--It is empty if other than person
	       COALESCE(sg.name, nsg.name, '') group_name,
	       d.[name] district_name,
	       c.contract_code,
	       p.code product_code,
	       CE.event_date AS [start_date],
	       InSn.expected_date AS [end_date],
	       AcCl.amount,
	       AcCl.olb,
	       AcCl.late_days,
	       u.first_name + ' ' + u.last_name loan_officer,
	       b.code branch_code
	FROM   @ActiveClients AS 
	       AcCl
	       INNER JOIN dbo.Credit AS Cr
	            ON  Cr.id = AcCl.contract_id
	       INNER JOIN Users u
	            ON  cr.loanofficer_id = u.id
	            AND (
	                    0 = @subordinate_id
	                    AND cr.loanofficer_id IN (SELECT id
	                                              FROM   @users)
	                    OR cr.loanofficer_id = @subordinate_id
	                )
	       INNER JOIN dbo.Contracts AS c
	            ON  c.id = AcCl.contract_id
	       INNER JOIN dbo.Projects pr
	            ON  c.project_id = pr.id
	       INNER JOIN dbo.Tiers tr
	            ON  tr.id = pr.tiers_id
	       LEFT JOIN Branches b ON tr.branch_id = b.id
	       LEFT JOIN dbo.Districts d
	            ON  tr.district_id = d.id
	       LEFT JOIN dbo.Persons AS Per
	            ON  Per.id = AcCl.id
	       LEFT JOIN dbo.Corporates AS Corp
	            ON  Corp.id = AcCl.id
	       LEFT JOIN Packages p
	            ON  cr.package_id = p.id
	       LEFT JOIN @ContractEvents CE
	            ON  CE.contract_id = AcCl.contract_id
	       LEFT JOIN @InstallmentSnapshot AS InSn
	            ON  InSn.contract_id = AcCl.contract_id
	       LEFT JOIN @SolidaryGroup sg
	            ON  sg.contract_id = AcCl.contract_id
	       LEFT JOIN @NonSolidaryGroup nsg
	            ON  nsg.person_id = Per.id
	ORDER BY
	       AcCl.contract_id,
	       Per.first_name,
	       Per.last_name,
	       Per.father_name
END