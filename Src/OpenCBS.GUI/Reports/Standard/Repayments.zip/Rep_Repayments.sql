 
CREATE PROCEDURE [dbo].[Rep_Repayments]
	@from DATETIME
	, @to DATETIME
	, @disbursed_in INT
	, @display_in INT
	, @user_id INT
	, @subordinate_id INT
	, @branch_id INT
AS BEGIN

	select isnull(re.event_date,se.creation_date) event_date
	, c.contract_code
	, cl.name
	, Us.first_name + SPACE(1) + Us.last_name AS loan_officer
	, Pack.name AS product
	, Br.code AS branch
	, isnull(se.amount,0) transit
	, isnull(re.principal,0) principal
	, case when c.start_date >= '01-01-2014'
	then CAST(isnull(re.interest,0) / Cr.interest_rate*(Cr.interest_rate-0.005) AS NUMERIC(16,2))
	else isnull(re.interest,0)
	end AS interest
	, case when c.start_date >= '01-01-2014'
	then CAST(isnull(re.interest,0)/ Cr.interest_rate*0.005 AS NUMERIC(16,2))
	else 0
	end AS commission
	, isnull(re.penalties,0) penalties
	, Case when (se.amount < re.principal+re.interest+re.penalties  )
	then 0
	else
	isnull(se.amount - re.principal - re.interest - re.penalties,0)
	end as total
	from
	(
	select r.contract_id, r.event_date, sum(r.principal) principal, sum(r.interest) interest, sum(r.penalties) penalties
	FROM dbo.Repayments(@from, @to, @user_id, @subordinate_id, @branch_id) AS r 
	group by r.contract_id, r.event_date) re
	full outer join (
	select description loan_id, sum(amount) amount, creation_date from SavingEvents
	
	where ISNUMERIC(description)=1 and deleted=0 and creation_date>=@from and creation_date<=@to 
	group by description, creation_date
	) 
	se on re.contract_id=se.loan_id and se.creation_date=re.event_date
	left join Contracts c on c.id=re.contract_id or se.loan_id=c.id
	left join Projects pr on pr.id=c.project_id
	left join Clients cl on cl.id=pr.tiers_id
	LEFT JOIN dbo.Credit AS Cr ON Cr.id = re.contract_id or Cr.id=se.loan_id
	LEFT JOIN dbo.Users AS Us ON Cr.loanofficer_id = Us.id
	LEFT JOIN dbo.Packages AS Pack ON Cr.package_id = Pack.id
	LEFT JOIN dbo.Tiers AS Trs ON pr.tiers_id = Trs.id
	LEFT JOIN dbo.Branches AS Br ON Br.id = Trs.branch_id
	
	where @subordinate_id=Us.id 
order by re.event_date
END
