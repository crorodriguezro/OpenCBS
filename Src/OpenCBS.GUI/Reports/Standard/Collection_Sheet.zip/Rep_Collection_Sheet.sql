CREATE PROCEDURE dbo.Rep_Collection_Sheet 
@beginDate DATETIME
,@endDate DATETIME
,@disbursed_in INT
,@display_in INT
, @user_id INT
, @subordinate_id INT
, @branch_id INT
AS BEGIN
	DECLARE @_beginDate DATETIME
	DECLARE @_endDate DATETIME
	DECLARE @_disbursed_in INT
	DECLARE @_display_in INT
	DECLARE @_user_id INT
	DECLARE @_subordinate_id INT
	DECLARE @_branch_id INT
	
	SET @_beginDate = @beginDate
	SET @_endDate = @endDate
	SET @_disbursed_in = @disbursed_in
	SET @_display_in = @display_in
	SET @_user_id = @user_id
	SET @_subordinate_id = @subordinate_id
	SET @_branch_id = @branch_id
	
	SELECT i.contract_id
	, i.expected_date
	, c.contract_code
	, al.amount
	, al.olb
	, cl.name AS client_name
	, t.city
	, d.name AS district_name
	, u.first_name + ' ' + u.last_name AS loan_officer_name
	, COALESCE(t.personal_phone, t.home_phone, secondary_personal_phone, secondary_home_phone) AS phone_number
	, i.principal - i.prepaid_principal AS principal
	, i.interest - i.prepaid_interest AS interest
	, dbo.GetXR(p.currency_id, @_display_in, @_beginDate) AS exchange_rate
	, i.principal + i.interest - i.prepaid_principal - i.prepaid_interest total
	FROM dbo.ExpectedInstallments_MC(@_beginDate, @_endDate, @_disbursed_in, @_display_in, @_user_id, @_subordinate_id, @_branch_id) AS i
	LEFT JOIN dbo.Contracts AS c ON c.id = i.contract_id
	LEFT JOIN dbo.Credit AS cr ON cr.id = c.id
	LEFT JOIN dbo.ActiveLoans_MC(@_beginDate, @_disbursed_in, @_display_in, @_branch_id) AS al ON al.id = c.id
	LEFT JOIN dbo.Projects AS j ON j.id = c.project_id
	LEFT JOIN dbo.Tiers AS t ON t.id = j.tiers_id
	LEFT JOIN dbo.Clients AS cl ON cl.id = t.id
	LEFT JOIN dbo.Districts AS d ON d.id = t.district_id
	LEFT JOIN dbo.Users AS u ON u.id = cr.loanofficer_id
	LEFT JOIN dbo.Packages AS p ON p.id = cr.package_id
	ORDER BY i.expected_date
END
