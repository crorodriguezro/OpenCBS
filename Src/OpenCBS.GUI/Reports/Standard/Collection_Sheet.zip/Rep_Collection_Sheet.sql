 CREATE PROCEDURE dbo.Rep_Collection_Sheet 
@beginDate DATETIME
, @endDate DATETIME
, @disbursed_in INT
, @display_in INT
, @user_id INT
, @subordinate_id INT
, @branch_id INT
AS BEGIN
	DECLARE @_beginDate DATETIME
	DECLARE @_endDate DATETIME
	DECLARE @_disbursed_in INT
	DECLARE @_display_in INT
	DECLARE @_user_id INT
	DECLARE @_subordinate_id INT
	DECLARE @_branch_id INT
	
	SET @_beginDate = @beginDate
	SET @_endDate = @endDate
	SET @_disbursed_in = @disbursed_in
	SET @_display_in = @display_in
	SET @_user_id = @user_id
	SET @_subordinate_id = @subordinate_id
	SET @_branch_id = @branch_id
	
	SELECT 
		  i.contract_id
		, i.expected_date
		, c.contract_code
	        , cr.amount
		, i.olb
		,substring(cl.name,0,CHARINDEX(' ',cl.name)) as client_first_name
                ,substring(cl.name,CHARINDEX(' ',cl.name),LEN(cl.name)) as client_last_name
		, t.city
		, d.name AS district_name
		, u.first_name + ' ' + u.last_name AS loan_officer_name
		, COALESCE(t.personal_phone, t.home_phone, secondary_personal_phone, secondary_home_phone) AS phone_number
		, CASE
		 WHEN c.start_date >= CAST('01-01-2014' as DATETIME) --if it is new 
		 THEN  (i.interest_repayment - i.paid_interest)/ cr.interest_rate *0.005  
		 ELSE  0  END AS commission
		,CASE
		 WHEN c.start_date >= CAST('01-01-2014' as DATETIME)--if it is new 
		 THEN  ((i.interest_repayment - i.paid_interest)-((i.interest_repayment - i.paid_interest)/ cr.interest_rate *0.005 ))  
		 ELSE  (i.interest_repayment - i.paid_interest)  END AS interest
		, i.capital_repayment - i.paid_capital AS principal
		, dbo.GetXR(p.currency_id, @_display_in, @_beginDate) AS exchange_rate
		, i.capital_repayment + i.interest_repayment - i.paid_capital - i.paid_interest total
		, ea.name AS activity_name
	FROM dbo.Installments AS i
	LEFT JOIN dbo.Contracts AS c ON c.id = i.contract_id
	LEFT JOIN dbo.Credit AS cr ON cr.id = c.id
	LEFT JOIN dbo.Projects AS j ON j.id = c.project_id
	LEFT JOIN dbo.Tiers AS t ON t.id = j.tiers_id
	LEFT JOIN dbo.Clients AS cl ON cl.id = t.id
	LEFT JOIN dbo.Districts AS d ON d.id = t.district_id
	LEFT JOIN dbo.Users AS u ON u.id = cr.loanofficer_id
	LEFT JOIN dbo.Packages AS p ON p.id = cr.package_id
	LEFT JOIN dbo.EconomicActivities AS ea ON ea.id = c.activity_id
        LEFT JOIN dbo.Branches b ON b.id = t.branch_id
	WHERE expected_date BETWEEN @beginDate AND @endDate
	    AND (capital_repayment > paid_capital OR interest_repayment > paid_interest)
	    AND (c.status = 5 OR c.status = 10)
	    AND (t.branch_id = @_branch_id OR @_branch_id = 0)
	ORDER BY i.expected_date, u.first_name, u.last_name
END

 