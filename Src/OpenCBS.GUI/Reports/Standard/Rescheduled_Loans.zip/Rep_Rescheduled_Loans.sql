CREATE PROCEDURE dbo.Rep_Rescheduled_Loans 
	@from DATETIME, @to DATETIME, @disbursed_in INT, @display_in INT, @branch_id INT
AS BEGIN
	SELECT u.first_name + ' ' + u.last_name loan_officer
		, cl.name client_name
		, c.contract_code
		, pack.name package_name
		, b.code AS branch_name
		, amt.amount * dbo.GetXR(pack.currency_id, @display_in, GETDATE()) loan_amount
		, rl.amount amount_rescheduled
		, rl.nb_of_maturity maturity
		, rl.reschedule_date
		, ISNULL(al.olb, 0) olb
	FROM dbo.RescheduledLoans_MC(@from, @to, @disbursed_in, @display_in, @branch_id) rl
	LEFT JOIN dbo.ActiveLoans_MC(GETDATE(), @disbursed_in, @display_in, @branch_id) al ON rl.contract_id = al.id
	LEFT JOIN dbo.Credit cr ON cr.id = rl.contract_id
	LEFT JOIN dbo.Contracts c ON c.id = rl.contract_id
	LEFT JOIN dbo.Projects j ON j.id = c.project_id
	LEFT JOIN dbo.Tiers t ON t.id = j.tiers_id
	LEFT JOIN dbo.Branches b ON b.id = t.branch_id
	LEFT JOIN dbo.Packages pack ON pack.id = cr.package_id
	LEFT JOIN dbo.Users u ON cr.loanofficer_id = u.id
	LEFT JOIN dbo.Clients cl ON cl.id = j.tiers_id
	LEFT JOIN (
		SELECT c.id contract_id
			, c.amount + ISNULL(SUM(te.amount), 0) amount
		FROM dbo.Credit c
		LEFT JOIN dbo.ContractEvents ce ON ce.contract_id = c.id
		LEFT JOIN dbo.TrancheEvents te ON te.id = ce.id
		WHERE ce.is_deleted = 0 AND ce.event_date <= GETDATE()
		GROUP BY c.id, c.amount
	) amt ON amt.contract_id = rl.contract_id
END
