﻿/****** Script for SelectTopNRows command from SSMS  ******/
CREATE PROCEDURE dbo.Rep_LoanLossProvision 
 @date_from DATETIME
,@date_to DATETIME
,@disbursed_in INT
,@display_in INT
,@branch_id INT

AS 
BEGIN
	SELECT 
			   CASE WHEN number_of_days_min=-1 AND number_of_days_max=-1 THEN 'Rescheduled'
			   ELSE CAST([number_of_days_min] as nvarchar(10))+'-'+CAST([number_of_days_max] as nvarchar(10)) END as categorie
			  ,[provisioning_value]*100 AS provisioning_value
			  ,ISNULL(begin_olb,0) as begin_olb
			  ,ISNULL(end_olb,0) as end_olb
			  ,ISNULL(begin_olb,0)*[provisioning_value] AS provision_begin
			  ,ISNULL(end_olb,0)*[provisioning_value] AS provision_end
			  ,ISNULL(end_olb*provisioning_value-begin_olb*provisioning_value,0)  AS provision_difference
	FROM
	(
		SELECT 
			  [dbo].[ProvisioningRules].[number_of_days_min]
			 ,[dbo].[ProvisioningRules].[number_of_days_max]
			 ,[provisioning_value]
			 ,SUM(ISNULL(begin_olb,0)) AS begin_olb
			 ,SUM(ISNULL(olb_end, 0)) AS end_olb
		  FROM [dbo].[ProvisioningRules]
		  LEFT JOIN
		  (  
			SELECT SUM(ISNULL(olb, 0)) AS begin_olb
			,pr.number_of_days_min
			,pr.number_of_days_max
			FROM dbo.ActiveLoans_MC(@date_from,@disbursed_in, @display_in, @branch_id) AS al
			INNER JOIN [dbo].[ProvisioningRules] AS pr ON 
														al.late_days>=pr.number_of_days_min 
														AND al.late_days<=pr.number_of_days_max
			INNER JOIN Credit as cr on cr.id=al.id
			INNER JOIN Packages as pkg on pkg.id=cr.package_id
			WHERE  cr.id NOT IN (SELECT contract_id FROM ContractEvents WHERE event_type='ROLE' AND is_deleted=0)
			GROUP BY pr.number_of_days_min, pr.number_of_days_max
			
			UNION ALL 
			
			SELECT SUM(ISNULL(olb, 0)) AS begin_olb
			,-1 AS number_of_days_min
			,-1 AS number_of_days_max
			FROM dbo.ActiveLoans_MC(@date_from, @disbursed_in, @display_in, @branch_id) AS al
			INNER JOIN Credit as cr on cr.id=al.id
			WHERE cr.id IN (SELECT contract_id FROM ContractEvents WHERE event_type='ROLE' AND is_deleted=0)
		  ) AS al_begin ON 
						  al_begin.number_of_days_min = ProvisioningRules.number_of_days_min 
						  AND al_begin.number_of_days_max = ProvisioningRules.number_of_days_max
		  
		  LEFT JOIN
		  (  
			SELECT SUM(ISNULL(olb,0)) AS olb_end
			, pr.number_of_days_min
			, pr.number_of_days_max
			FROM dbo.ActiveLoans_MC(@date_to, @disbursed_in, @display_in, @branch_id) AS al
			INNER JOIN [dbo].[ProvisioningRules] AS pr ON 
														al.late_days>=pr.number_of_days_min 
														AND al.late_days<=pr.number_of_days_max
			INNER JOIN Credit as cr on cr.id=al.id
			WHERE cr.id NOT IN (SELECT contract_id FROM ContractEvents WHERE event_type='ROLE' AND is_deleted=0)
			GROUP BY pr.number_of_days_min, pr.number_of_days_max
			
			UNION ALL
			
			SELECT SUM(ISNULL(olb,0)) AS olb_end
			, -1 AS number_of_days_min
			, -1 AS number_of_days_max
			FROM dbo.ActiveLoans_MC(@date_to, @disbursed_in, @display_in, @branch_id) AS al
			INNER JOIN Credit as cr on cr.id=al.id
			WHERE cr.id IN (SELECT contract_id FROM ContractEvents WHERE event_type='ROLE' AND is_deleted=0)
		 ) AS al_end ON 
						al_end.number_of_days_min = ProvisioningRules.number_of_days_min 
						AND al_end.number_of_days_max = ProvisioningRules.number_of_days_max
		GROUP BY  [dbo].[ProvisioningRules].[number_of_days_min]
		, [dbo].[ProvisioningRules].[number_of_days_max]
		, [provisioning_value]
	) as prov
END