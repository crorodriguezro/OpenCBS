CREATE PROCEDURE dbo.Rep_LoanDistribution @date DATETIME, @disbursed_in INT, @display_in INT,@branch_id INT
AS BEGIN
select ea.name
,m.olb AS male_olb
,f.olb AS female_olb
,(ISNULL(m.olb,0)+ISNULL(f.olb,0)) AS total_olb
,m.loans AS male_loans
,f.loans AS female_loans
,(ISNULL(m.loans,0)+ISNULL(f.loans,0)) AS total_loans
from (  select pe.activity_id, SUM(ac.olb) AS olb, COUNT(*) AS loans
		from ActiveClients_MC(@date,@disbursed_in,@display_in,@branch_id) ac
		inner join Persons pe on pe.id = ac.id		
		where pe.sex = 'M'
		group by pe.activity_id	
		) m
right join EconomicActivities ea on ea.id = m.activity_id 
left join 
   (select pe.activity_id, SUM(ac.olb) AS olb, COUNT(*) AS loans
	from ActiveClients_MC(GETDATE(),@disbursed_in,@display_in,@branch_id) ac
	inner join Persons pe on pe.id = ac.id	
	where pe.sex = 'F'
	group by pe.activity_id) f ON f.activity_id = ea.id 
where ea.deleted = 0
order by ea.name
END