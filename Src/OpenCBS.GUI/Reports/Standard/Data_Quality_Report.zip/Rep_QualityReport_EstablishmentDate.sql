CREATE PROCEDURE [dbo].[Rep_QualityReport_EstablishmentDate]
AS
	BEGIN
		SELECT     dbo.Contracts.id, dbo.Contracts.contract_code, dbo.Groups.name AS group_name, dbo.Users.first_name + ' ' + dbo.Users.last_name AS loan_officer, 
                      dbo.Groups.establishment_date
FROM         dbo.Contracts INNER JOIN
                      dbo.Credit ON dbo.Credit.id = dbo.Contracts.id INNER JOIN
                      dbo.Projects ON dbo.Contracts.project_id = dbo.Projects.id INNER JOIN
                      dbo.Tiers ON dbo.Tiers.id = dbo.Projects.tiers_id INNER JOIN
                      dbo.Groups ON dbo.Groups.id = dbo.Tiers.id INNER JOIN
                      dbo.Users ON dbo.Users.id = dbo.Credit.loanofficer_id
WHERE     (dbo.Groups.establishment_date IS NULL)
GROUP BY dbo.Contracts.id, dbo.Contracts.contract_code, dbo.Groups.name, dbo.Users.first_name + ' ' + dbo.Users.last_name, dbo.Groups.establishment_date
	END


