CREATE PROCEDURE [dbo].[Rep_QualityReport_GroupMembers] @branch_id INT
AS
BEGIN
		SELECT    Contracts.contract_code
FROM         dbo.Contracts INNER JOIN
			activeloans(getdate(), @branch_id) al on al.id=contracts.id inner join
                      dbo.Projects ON dbo.Projects.id = dbo.Contracts.project_id INNER JOIN
                      dbo.Tiers ON dbo.Projects.tiers_id = dbo.Tiers.id
WHERE     (dbo.Tiers.client_type_code = 'G') AND
                          ((SELECT     COUNT(person_id) AS Expr1
                              FROM         dbo.PersonGroupBelonging AS PersonGroupBelonging_1
                              WHERE     (group_id = dbo.Projects.tiers_id)) = 0)

	END


