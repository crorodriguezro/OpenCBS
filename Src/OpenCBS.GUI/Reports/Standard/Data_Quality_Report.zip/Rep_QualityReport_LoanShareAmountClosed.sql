CREATE PROCEDURE [dbo].[Rep_QualityReport_LoanShareAmountClosed]
AS
	BEGIN
SELECT  contracts.id,SUM(amount) as total_shares
INTO #share_temp
from contracts 
left join loanshareamounts on loanshareamounts.contract_id = contracts.id
group by contracts.id
		SELECT     Contract_code, total_shares, credit.amount
FROM         credit 
			 left join contracts on contracts.id = credit.id
			 left join #share_temp on #share_temp.id = contracts.id
WHERE #share_temp.total_shares <> credit.amount
END