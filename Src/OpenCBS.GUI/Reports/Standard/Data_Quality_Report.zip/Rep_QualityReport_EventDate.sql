CREATE PROCEDURE [dbo].[Rep_QualityReport_EventDate]
AS
	BEGIN
		SELECT     dbo.Contracts.contract_code, dbo.ContractEvents.event_type, dbo.ContractEvents.event_date
FROM         dbo.ContractEvents INNER JOIN
                      dbo.Contracts ON dbo.Contracts.id = dbo.ContractEvents.contract_id
WHERE     (dbo.ContractEvents.event_date > GETDATE())
	END


