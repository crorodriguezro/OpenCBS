CREATE PROCEDURE dbo.Rep_Tranches @from DATETIME,@to DATETIME,@disbursed_in INT,@display_in INT,@branch_id INT
AS BEGIN
	SELECT ce.event_date
	,te.start_date AS tranche_date
	,cl.name as client_name
	,u.first_name+' '+u.last_name AS loan_officer
	, co.contract_code
	,pkg.code AS lp_code
	,te.amount*dbo.GetXR(pkg.currency_id,@display_in,ce.event_date) AS amount
	,te.interest_rate
	,te.maturity
	,(dbo.GetOLB(co.id,ce.event_date)-te.amount)*dbo.GetXR(pkg.currency_id,@display_in,ce.event_date) AS olb
	FROM ContractEvents ce
	INNER JOIN TrancheEvents te on te.id = ce.id
	INNER JOIN Contracts co on co.id = ce.contract_id
	INNER JOIN Projects pr on pr.id = co.project_id
	INNER JOIN Tiers ti on ti.id = pr.tiers_id
	INNER JOIN Credit cr on cr.id=co.id
	INNER JOIN Packages pkg on pkg.id = cr.package_id
	INNER JOIN Users u on u.id = cr.loanofficer_id
	INNER JOIN Clients cl on cl.id = pr.tiers_id
	WHERE 
	    ce.is_deleted = 0
	    AND ce.event_date BETWEEN	@from AND @to 
	    AND (pkg.currency_id=@disbursed_in OR @disbursed_in = 0)
	    AND (0 = @branch_id OR ti.branch_id = @branch_id)
END
