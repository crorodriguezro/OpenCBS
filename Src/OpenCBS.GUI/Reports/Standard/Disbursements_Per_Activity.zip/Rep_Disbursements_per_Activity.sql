CREATE PROCEDURE dbo.Rep_Disbursements_per_Activity
	@start_date DATETIME
	, @end_date DATETIME
	, @disbursed_in INT
	, @display_in INT
	, @branch_id INT
	, @user_id INT
	, @subordinate_id INT
AS BEGIN
	WITH _lsa
	AS
	(
		SELECT lsa1.person_id, lsa1.group_id, lsa1.contract_id, lsa1.amount,
		ROW_NUMBER() OVER (PARTITION BY lsa1.contract_id ORDER BY person_id) AS number, lsa2.total
		FROM dbo.LoanShareAmounts AS lsa1
		LEFT JOIN
		(
			SELECT contract_id, COUNT(person_id) AS total
			FROM dbo.LoanShareAmounts
			GROUP BY contract_id
		) AS lsa2 ON lsa1.contract_id = lsa2.contract_id
	)
	, _clients
	AS
	(
		SELECT a.name AS activity, _c.*
		FROM
		(
			SELECT ISNULL(p1.id, p2.id) AS client_id, c.contract_code, pkg.code AS loan_product, t.loan_cycle, d.contract_id, d.disbursement_date,
			u.first_name + ' ' + u.last_name AS loan_officer, dist.name AS district,
			ISNULL(p1.activity_id, p2.activity_id) AS activity_id,
			ISNULL(p1.first_name + ' ' + p1.last_name, p2.first_name + ' ' + p2.last_name) AS client_name,
			CASE
				WHEN _lsa.amount IS NULL THEN 1
				ELSE _lsa.number
			END AS number,
			CASE
				WHEN _lsa.amount IS NULL THEN 1
				ELSE _lsa.total
			END AS total,
			CASE 
				WHEN _lsa.amount IS NULL THEN CAST(d.amount * dbo.GetXR(pkg.currency_id, @display_in, d.disbursement_date) AS MONEY)
				ELSE CAST(_lsa.amount * dbo.GetXR(pkg.currency_id, @display_in, d.disbursement_date) AS MONEY)
			END AS amount,
			CASE
				WHEN _lsa.amount IS NULL THEN CAST(d.interest * dbo.GetXR(pkg.currency_id, @display_in, d.disbursement_date) AS MONEY)
				ELSE CASE
					WHEN _lsa.number < _lsa.total THEN CAST(FLOOR(d.interest * _lsa.amount / d.amount) * dbo.GetXR(pkg.currency_id, @display_in, d.disbursement_date) AS MONEY)
					--ELSE CAST((d.interest - (_lsa.total - 1) * FLOOR(d.interest / _lsa.total)) * dbo.GetXR(pkg.currency_id, @display_in, d.disbursement_date) AS MONEY)
					ELSE CAST(d.interest * dbo.GetXR(pkg.currency_id, @display_in, d.disbursement_date) AS MONEY)
				END	
			END AS interest,
			CASE
				WHEN _lsa.amount IS NULL THEN CAST(d.fees * dbo.GetXR(pkg.currency_id, @display_in, d.disbursement_date) AS MONEY)
				ELSE CASE
					WHEN _lsa.number < _lsa.total THEN CAST(FLOOR(d.fees / _lsa.total) * dbo.GetXR(pkg.currency_id, @display_in, d.disbursement_date) AS MONEY)
					--ELSE CAST((d.fees - (_lsa.total - 1) * FLOOR(d.fees / _lsa.total)) * dbo.GetXR(pkg.currency_id, @display_in, d.disbursement_date) AS MONEY)
					ELSE CAST(d.fees * dbo.GetXR(pkg.currency_id, @display_in, d.disbursement_date) AS MONEY)
				END	
			END AS fees
			FROM dbo.Disbursements(@start_date, @end_date, @user_id, @subordinate_id, @branch_id) AS d
			LEFT JOIN dbo.Contracts AS c ON c.id = d.contract_id
			LEFT JOIN dbo.Credit AS cr ON cr.id = c.id
			LEFT JOIN dbo.Packages AS pkg ON pkg.id = cr.package_id
			LEFT JOIN dbo.Projects AS j ON j.id = c.project_id
			LEFT JOIN dbo.Tiers AS t ON t.id = j.tiers_id
			LEFT JOIN _lsa ON _lsa.contract_id = d.contract_id
			LEFT JOIN dbo.Persons AS p1 ON p1.id = t.id
			LEFT JOIN dbo.Persons AS p2 ON p2.id = _lsa.person_id
			LEFT JOIN dbo.Users AS u ON u.id = cr.loanofficer_id
			LEFT JOIN dbo.Districts AS dist ON dist.id = t.district_id
			WHERE d.disbursed = 1 AND (pkg.currency_id = @disbursed_in OR 0 = @disbursed_in)
		) AS _c
		LEFT JOIN dbo.EconomicActivities AS a ON a.id = _c.activity_id
	)
	, _rt
	AS
	(
		SELECT c1.client_id, c1.contract_id, 
		ISNULL(SUM(c2.interest), 0) AS rt_interest,
		ISNULL(SUM(c2.fees), 0) AS rt_fees
		FROM _clients AS c1
		LEFT JOIN _clients AS c2 ON c1.contract_id = c2.contract_id AND c1.number > c2.number
		GROUP BY c1.client_id, c1.contract_id
	)
	SELECT c.activity, c.contract_code, c.loan_product, c.loan_cycle,
	c.contract_id, c.disbursement_date, c.loan_officer, c.district, c.activity_id,
	c.client_name, c.amount,
	CASE
		WHEN c.number < c.total THEN c.interest
		ELSE c.interest - _rt.rt_interest
	END AS interest,
	CASE
		WHEN c.number < c.total THEN c.fees
		ELSE c.fees - _rt.rt_fees
	END AS fees
	FROM _clients AS c
	LEFT JOIN _rt ON _rt.client_id = c.client_id AND _rt.contract_id = c.contract_id
	ORDER BY activity, loan_officer, disbursement_date
END
