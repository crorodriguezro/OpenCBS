CREATE PROCEDURE dbo.Rep_Portfolio_Transfer @date DATETIME, @period INT, @disbursed_in INT, @display_in INT, @branch_id INT
AS BEGIN
	DECLARE @start DATETIME
	SET @start = DATEADD(dd, -@period, @date)

	;WITH _history
	AS
	(
		SELECT CAST(FLOOR(CAST(DateChanged AS FLOAT)) AS DATETIME) AS [date],
		loanofficerFrom_id AS [from], loanofficerTo_id AS [to], contract_id
		FROM dbo.ContractAssignHistory
	),
	_clients
	AS
	(
		SELECT ac.id, ac.contract_id, CAST(ac.olb * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS olb,
		CASE WHEN 0 = ac.late_days THEN 0 ELSE CAST(ac.olb * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) END AS par
		FROM dbo.ActiveClients(@date, @branch_id) AS ac
		LEFT JOIN dbo.Credit AS cr ON cr.id = ac.contract_id
		LEFT JOIN dbo.Packages AS pkg ON cr.package_id = pkg.id
		WHERE pkg.currency_id = @disbursed_in OR 0 = @disbursed_in
	)
	SELECT u.id, u.first_name + ' ' + u.last_name AS name,
	ISNULL(outgoing.clients, 0) AS outgoing_clients, 
	ISNULL(outgoing.contracts, 0) AS outgoing_contracts,
	ISNULL(outgoing.olb, 0) AS outgoing_olb, ISNULL(outgoing.par, 0) AS outgoing_par,
	ISNULL(incoming.clients, 0) AS incoming_clients,
	ISNULL(incoming.contracts, 0) AS incoming_contracts,
	ISNULL(incoming.olb, 0) AS incoming_olb, ISNULL(incoming.par, 0) AS incoming_par,
	ISNULL(actual.clients, 0) AS actual_clients,
	ISNULL(actual.contracts, 0) AS actual_contracts,
	ISNULL(actual.olb, 0) AS actual_olb, ISNULL(actual.par, 0) AS actual_par
	FROM dbo.Users AS u
	LEFT JOIN
	(
		SELECT COUNT(DISTINCT ac.contract_id) AS contracts, 
		COUNT(ac.id) AS clients, h.[from] AS loan_officer_id,
		SUM(ac.olb) AS olb, SUM(par) AS par
		FROM _clients AS ac
		RIGHT JOIN _history AS h ON h.contract_id = ac.contract_id
		WHERE h.[date] BETWEEN @start AND @date
		GROUP BY h.[from]
	) AS outgoing ON u.id = outgoing.loan_officer_id
	LEFT JOIN
	(
		SELECT COUNT(DISTINCT ac.contract_id) AS contracts, 
		COUNT(ac.id) AS clients, h.[to] AS loan_officer_id,
		SUM(ac.olb) AS olb, SUM(par) AS par
		FROM _clients AS ac
		RIGHT JOIN _history AS h ON h.contract_id = ac.contract_id
		WHERE h.[date] BETWEEN @start AND @date
		GROUP BY h.[to]
	) AS incoming ON u.id = incoming.loan_officer_id
	LEFT JOIN
	(
		SELECT COUNT(DISTINCT ac.contract_id) AS contracts,
		COUNT(ac.id) AS clients, cr.loanofficer_id AS loan_officer_id,
		SUM(ac.olb) AS olb, SUM(par) AS par
		FROM _clients AS ac
		LEFT JOIN dbo.Credit AS cr ON cr.id = ac.contract_id
		GROUP BY cr.loanofficer_id
	) AS actual ON u.id = actual.loan_officer_id
END
