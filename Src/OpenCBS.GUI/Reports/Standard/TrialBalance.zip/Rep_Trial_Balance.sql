CREATE PROCEDURE dbo.Rep_Trial_Balance @from DATETIME, @to DATETIME, @disbursed_in INT, @display_in INT, @branch_id INT
AS BEGIN
	DECLARE @_from DATETIME
	DECLARE @_to DATETIME
	SET @_from = CAST(ROUND(CAST(@from AS FLOAT), 0) AS DATETIME)
	SET @_to = CAST(ROUND(CAST(@to AS FLOAT), 0) AS DATETIME)
	DECLARE @from_prev_day DATETIME
	SET @from_prev_day = DATEADD(dd, -1, @_from)

	SELECT tb1.account_id
		, tb1.account_number
		, tb1.account_label
		, ac.category_name
		, am.debit
		, am.credit
		, tb1.balance opening_balance
		, tb2.balance closing_balance
		, am.agg_debit
		, am.agg_credit
		, tb1.agg_balance agg_opening_balance
		, tb2.agg_balance agg_closing_balance
		, coa.indentation
	FROM dbo.TrialBalance(@from_prev_day, @disbursed_in, @display_in, 0, @branch_id, 7) tb1
	LEFT JOIN dbo.TrialBalance(@_to, @disbursed_in, @display_in, 0, @branch_id, 7) tb2 ON tb2.account_id = tb1.account_id
	LEFT JOIN dbo.AccountMovements(@from, @_to, @disbursed_in, @display_in, 0, @branch_id, 7) am ON am.account_id = tb1.account_id
	LEFT JOIN 
	(	SELECT id category_id
			, name category_name
			, CASE
				WHEN name LIKE '%asset%' THEN 1
				WHEN name LIKE '%liab%' THEN 2
				WHEN name LIKE '%income%' OR name LIKE '%revenue%' THEN 3
				ELSE 4
			END category_order
		FROM dbo.AccountsCategory
	) ac ON ac.category_id = tb1.account_category_id
	LEFT JOIN
	(
		SELECT COUNT(coa2.id)-1 indentation, coa1.id, coa1.lft
		FROM dbo.ChartOfAccounts coa1, dbo.ChartOfAccounts coa2
		WHERE coa1.lft BETWEEN coa2.lft AND coa2.rgt
		GROUP BY coa1.id, coa1.label, coa1.lft		
	) coa ON coa.id = tb1.account_id
	ORDER BY ac.category_order, coa.lft
END