CREATE PROCEDURE dbo.Rep_PAR_Analysis @date DATETIME, @user_id INT, @branch_id NVARCHAR(MAX), @subordinate_id INT, @disbursed_in INT, @display_in INT
AS BEGIN
		DECLARE @active_clients TABLE
		(
			id INT NOT NULL
			, contract_id INT NOT NULL
			, olb MONEY NOT NULL
			, late_days INT NOT NULL
			, district_id INT NOT NULL
			, loan_officer_id INT NOT NULL
			, product_id INT NOT NULL
			, client_type_code CHAR(1) NOT NULL
			, activity_id INT NOT NULL
			, branch_id INT NOT NULL
			, num INT NOT NULL
			
		)

		DECLARE @active_loans TABLE
		(
			id INT NOT NULL
			, olb MONEY NOT NULL
			, late_days INT NOT NULL
			, district_id INT NOT NULL
		)

		DECLARE @users TABLE
		(
			id INT NOT NULL
		)
		
		INSERT INTO @users
		SELECT @user_id
		INSERT INTO @users
		SELECT subordinate_id
		FROM dbo.UsersSubordinates
		WHERE user_id = @user_id
		
		INSERT INTO @active_clients
		SELECT ac.id
			, ac.contract_id
			, ac.olb
			, ac.late_days
			, isnull(t3.district_id,t.district_id)
			, cr.loanofficer_id
			, cr.package_id
			, t2.client_type_code
			, ISNULL(p.activity_id, cp.activity_id) activity_id
			, t.branch_id
			, ROW_NUMBER() OVER (PARTITION BY ac.contract_id ORDER BY ac.contract_id) row
		FROM dbo.ActiveClients_MC(@date, @disbursed_in, @display_in, 0) ac
		INNER JOIN dbo.Contracts c ON c.id = ac.contract_id
		INNER JOIN dbo.Credit cr ON cr.id = c.id
		INNER JOIN dbo.Projects j ON j.id = c.project_id
		LEFT JOIN dbo.Tiers t2 ON t2.id = j.tiers_id
		LEFT JOIN dbo.Tiers t ON t.id = ac.id
		LEFT JOIN dbo.PersonGroupBelonging pgb on pgb.person_id = t.id 
		LEFT JOIN dbo.Groups gr on gr.id = pgb.group_id
		Left join dbo.Tiers t3 on t3.id = gr.id
		LEFT JOIN dbo.persons p ON p.id = t.id
		LEFT JOIN dbo.Corporates cp ON cp.id = t.id
		WHERE ('0' = @branch_id OR t.branch_id IN (SELECT number FROM dbo.IntListToTable(@branch_id)))
			AND (0 = @subordinate_id AND cr.loanofficer_id IN (SELECT id FROM @users) OR cr.loanofficer_id = @subordinate_id)

		INSERT INTO @active_loans
		SELECT ac.contract_id, SUM(ac.olb), ac.late_days, t.district_id
		FROM @active_clients ac
		INNER JOIN dbo.Contracts c ON c.id = ac.contract_id
		INNER JOIN dbo.Projects j ON j.id = c.project_id
		LEFT JOIN dbo.Tiers t ON t.id = j.tiers_id
		GROUP BY ac.contract_id, ac.late_days, t.district_id

		SELECT 'district' break_down_type
			, d.name break_down
			, ac.olb
			, ac.par
			, ac.clients
			, ac.all_clients
			, al.contracts
			, al.all_contracts
			, ac.par_30
			, ac.clients_30
			, al.contracts_30
			, ac.par_1_30
			, ac.clients_1_30
			, al.contracts_1_30
			, ac.par_31_60
			, ac.clients_31_60
			, al.contracts_31_60
			, ac.par_61_90
			, ac.clients_61_90
			, al.contracts_61_90
			, ac.par_91_180
			, ac.clients_91_180
			, al.contracts_91_180
			, ac.par_181_365
			, ac.clients_181_365
			, al.contracts_181_365
			, ac.par_365
			, ac.clients_365
			, al.contracts_365
		FROM
		(
			SELECT district_id
				, SUM(olb) olb
				, SUM(CASE WHEN late_days > 0 THEN olb ELSE 0 END) par
				, SUM(CASE WHEN late_days > 0 THEN 1 ELSE 0 END) clients
				, COUNT(DISTINCT id) all_clients
				, SUM(CASE WHEN late_days > 30 THEN olb ELSE 0 END) par_30
				, SUM(CASE WHEN late_days > 30 THEN 1 ELSE 0 END) clients_30
				, SUM(CASE WHEN late_days BETWEEN 1 AND 30 THEN olb ELSE 0 END) par_1_30
				, SUM(CASE WHEN late_days BETWEEN 1 AND 30 THEN 1 ELSE 0 END) clients_1_30
				, SUM(CASE WHEN late_days BETWEEN 31 AND 60 THEN olb ELSE 0 END) par_31_60
				, SUM(CASE WHEN late_days BETWEEN 31 AND 60 THEN 1 ELSE 0 END) clients_31_60
				, SUM(CASE WHEN late_days BETWEEN 61 AND 90 THEN olb ELSE 0 END) par_61_90
				, SUM(CASE WHEN late_days BETWEEN 61 AND 90 THEN 1 ELSE 0 END) clients_61_90
				, SUM(CASE WHEN late_days BETWEEN 91 AND 180 THEN olb ELSE 0 END) par_91_180
				, SUM(CASE WHEN late_days BETWEEN 91 AND 180 THEN 1 ELSE 0 END) clients_91_180
				, SUM(CASE WHEN late_days BETWEEN 181 AND 365 THEN olb ELSE 0 END) par_181_365
				, SUM(CASE WHEN late_days BETWEEN 181 AND 365 THEN 1 ELSE 0 END) clients_181_365   
				, SUM(CASE WHEN late_days > 365 THEN olb ELSE 0 END) par_365
				, SUM(CASE WHEN late_days > 365 THEN 1 ELSE 0 END) clients_365
			FROM @active_clients
			GROUP BY district_id
		) ac
		LEFT JOIN
		(
			SELECT district_id
				, SUM(CASE WHEN late_days > 0 THEN 1 ELSE 0 END) contracts
				, COUNT(id) all_contracts
				, SUM(CASE WHEN late_days > 30 THEN 1 ELSE 0 END) contracts_30
				, SUM(CASE WHEN late_days BETWEEN 1 AND 30 THEN 1 ELSE 0 END) contracts_1_30
				, SUM(CASE WHEN late_days BETWEEN 31 AND 60 THEN 1 ELSE 0 END) contracts_31_60
				, SUM(CASE WHEN late_days BETWEEN 61 AND 90 THEN 1 ELSE 0 END) contracts_61_90
				, SUM(CASE WHEN late_days BETWEEN 91 AND 180 THEN 1 ELSE 0 END) contracts_91_180
				, SUM(CASE WHEN late_days BETWEEN 181 AND 365 THEN 1 ELSE 0 END) contracts_181_365
				, SUM(CASE WHEN late_days > 365 THEN 1 ELSE 0 END) contracts_365
			FROM @active_loans
			GROUP BY district_id
		) al ON ac.district_id = al.district_id
		LEFT JOIN dbo.Districts d ON d.id = ac.district_id

		UNION ALL
		
		SELECT 'loan_officer' break_down_type
			, u.first_name + ' ' + u.last_name break_down
			, SUM(olb) olb
			, SUM(CASE WHEN late_days > 0 THEN olb ELSE 0 END) par
			, SUM(CASE WHEN late_days > 0 THEN 1 ELSE 0 END) clients
			, COUNT(DISTINCT ac.id) all_clients
			, SUM(CASE WHEN late_days > 0 AND 1 = num THEN 1 ELSE 0 END) contracts
			, SUM(CASE WHEN 1 = num THEN 1 ELSE 0 END) all_contracts
			, SUM(CASE WHEN late_days > 30 THEN olb ELSE 0 END) par_30
			, SUM(CASE WHEN late_days > 30 THEN 1 ELSE 0 END) clients_30
			, SUM(CASE WHEN late_days > 30 AND 1 = num THEN 1 ELSE 0 END) contracts_30
			, SUM(CASE WHEN late_days BETWEEN 1 AND 30 THEN olb ELSE 0 END) par_1_30
			, SUM(CASE WHEN late_days BETWEEN 1 AND 30 THEN 1 ELSE 0 END) clients_1_30
			, SUM(CASE WHEN late_days BETWEEN 1 AND 30 AND 1 = num THEN 1 ELSE 0 END) contracts_1_30
			, SUM(CASE WHEN late_days BETWEEN 31 AND 60 THEN olb ELSE 0 END) par_31_60
			, SUM(CASE WHEN late_days BETWEEN 31 AND 60 THEN 1 ELSE 0 END) clients_31_60
			, SUM(CASE WHEN late_days BETWEEN 31 AND 60 AND 1 = num THEN 1 ELSE 0 END) contracts_31_60
			, SUM(CASE WHEN late_days BETWEEN 61 AND 90 THEN olb ELSE 0 END) par_61_90
			, SUM(CASE WHEN late_days BETWEEN 61 AND 90 THEN 1 ELSE 0 END) clients_61_90
			, SUM(CASE WHEN late_days BETWEEN 61 AND 90 AND 1 = num THEN 1 ELSE 0 END) contracts_61_90
			, SUM(CASE WHEN late_days BETWEEN 91 AND 180 THEN olb ELSE 0 END) par_91_180
			, SUM(CASE WHEN late_days BETWEEN 91 AND 180 THEN 1 ELSE 0 END) clients_91_180
			, SUM(CASE WHEN late_days BETWEEN 91 AND 180 AND 1 = num THEN 1 ELSE 0 END) contracts_91_180
			, SUM(CASE WHEN late_days BETWEEN 181 AND 365 THEN olb ELSE 0 END) par_181_365
			, SUM(CASE WHEN late_days BETWEEN 181 AND 365 THEN 1 ELSE 0 END) clients_181_365
			, SUM(CASE WHEN late_days BETWEEN 181 AND 365 AND 1 = num THEN 1 ELSE 0 END) contracts_181_365
			, SUM(CASE WHEN late_days > 365 THEN olb ELSE 0 END) par_365
			, SUM(CASE WHEN late_days > 365 THEN 1 ELSE 0 END) clients_365
			, SUM(CASE WHEN late_days > 365 AND 1 = num THEN 1 ELSE 0 END) contracts_365
		FROM @active_clients ac
		LEFT JOIN dbo.Users u ON u.id = ac.loan_officer_Id
		GROUP BY loan_officer_id, u.first_name, u.last_name

		UNION ALL
		
		SELECT 'product' break_down_type
			, pack.name break_down
			, SUM(olb) olb
			, SUM(CASE WHEN late_days > 0 THEN olb ELSE 0 END) par
			, SUM(CASE WHEN late_days > 0 THEN 1 ELSE 0 END) clients
			, COUNT(DISTINCT ac.id) all_clients
			, SUM(CASE WHEN late_days > 0 AND 1 = num THEN 1 ELSE 0 END) contracts
			, SUM(CASE WHEN 1 = num THEN 1 ELSE 0 END) all_contracts
			, SUM(CASE WHEN late_days > 30 THEN olb ELSE 0 END) par_30
			, SUM(CASE WHEN late_days > 30 THEN 1 ELSE 0 END) clients_30
			, SUM(CASE WHEN late_days > 30 AND 1 = num THEN 1 ELSE 0 END) contracts_30
			, SUM(CASE WHEN late_days BETWEEN 1 AND 30 THEN olb ELSE 0 END) par_1_30
			, SUM(CASE WHEN late_days BETWEEN 1 AND 30 THEN 1 ELSE 0 END) clients_1_30
			, SUM(CASE WHEN late_days BETWEEN 1 AND 30 AND 1 = num THEN 1 ELSE 0 END) contracts_1_30
			, SUM(CASE WHEN late_days BETWEEN 31 AND 60 THEN olb ELSE 0 END) par_31_60
			, SUM(CASE WHEN late_days BETWEEN 31 AND 60 THEN 1 ELSE 0 END) clients_31_60
			, SUM(CASE WHEN late_days BETWEEN 31 AND 60 AND 1 = num THEN 1 ELSE 0 END) contracts_31_60
			, SUM(CASE WHEN late_days BETWEEN 61 AND 90 THEN olb ELSE 0 END) par_61_90
			, SUM(CASE WHEN late_days BETWEEN 61 AND 90 THEN 1 ELSE 0 END) clients_61_90
			, SUM(CASE WHEN late_days BETWEEN 61 AND 90 AND 1 = num THEN 1 ELSE 0 END) contracts_61_90
			, SUM(CASE WHEN late_days BETWEEN 91 AND 180 THEN olb ELSE 0 END) par_91_180
			, SUM(CASE WHEN late_days BETWEEN 91 AND 180 THEN 1 ELSE 0 END) clients_91_180
			, SUM(CASE WHEN late_days BETWEEN 91 AND 180 AND 1 = num THEN 1 ELSE 0 END) contracts_91_180
			, SUM(CASE WHEN late_days BETWEEN 181 AND 365 THEN olb ELSE 0 END) par_181_365
			, SUM(CASE WHEN late_days BETWEEN 181 AND 365 THEN 1 ELSE 0 END) clients_181_365
			, SUM(CASE WHEN late_days BETWEEN 181 AND 365 AND 1 = num THEN 1 ELSE 0 END) contracts_181_365
			, SUM(CASE WHEN late_days > 365 THEN olb ELSE 0 END) par_365
			, SUM(CASE WHEN late_days > 365 THEN 1 ELSE 0 END) clients_365
			, SUM(CASE WHEN late_days > 365 AND 1 = num THEN 1 ELSE 0 END) contracts_365
		FROM @active_clients ac
		LEFT JOIN dbo.Packages pack ON pack.id = ac.product_id
		GROUP BY pack.id, pack.name

		UNION ALL
		
		SELECT 'activity' break_down_type
			, doa.name break_down
			, SUM(olb) olb
			, SUM(CASE WHEN late_days > 0 THEN olb ELSE 0 END) par
			, SUM(CASE WHEN late_days > 0 THEN 1 ELSE 0 END) clients
			, COUNT(DISTINCT ac.id) all_clients
			, SUM(CASE WHEN late_days > 0 AND 1 = num THEN 1 ELSE 0 END) contracts
			, SUM(CASE WHEN 'I' = client_type_code THEN 1 ELSE 0 END) all_contracts
			, SUM(CASE WHEN late_days > 30 THEN olb ELSE 0 END) par_30
			, SUM(CASE WHEN late_days > 30 THEN 1 ELSE 0 END) clients_30
			, SUM(CASE WHEN late_days > 30 AND 'I' = client_type_code THEN 1 ELSE 0 END) contracts_30
			, SUM(CASE WHEN late_days BETWEEN 1 AND 30 THEN olb ELSE 0 END) par_1_30
			, SUM(CASE WHEN late_days BETWEEN 1 AND 30 THEN 1 ELSE 0 END) clients_1_30
			, SUM(CASE WHEN late_days BETWEEN 1 AND 30 AND 'I' = client_type_code THEN 1 ELSE 0 END) contracts_1_30
			, SUM(CASE WHEN late_days BETWEEN 31 AND 60 THEN olb ELSE 0 END) par_31_60
			, SUM(CASE WHEN late_days BETWEEN 31 AND 60 THEN 1 ELSE 0 END) clients_31_60
			, SUM(CASE WHEN late_days BETWEEN 31 AND 60 AND 'I' = client_type_code THEN 1 ELSE 0 END) contracts_31_60
			, SUM(CASE WHEN late_days BETWEEN 61 AND 90 THEN olb ELSE 0 END) par_61_90
			, SUM(CASE WHEN late_days BETWEEN 61 AND 90 THEN 1 ELSE 0 END) clients_61_90
			, SUM(CASE WHEN late_days BETWEEN 61 AND 90 AND 'I' = client_type_code THEN 1 ELSE 0 END) contracts_61_90
			, SUM(CASE WHEN late_days BETWEEN 91 AND 180 THEN olb ELSE 0 END) par_91_180
			, SUM(CASE WHEN late_days BETWEEN 91 AND 180 THEN 1 ELSE 0 END) clients_91_180
			, SUM(CASE WHEN late_days BETWEEN 91 AND 180 AND 'I' = client_type_code THEN 1 ELSE 0 END) contracts_91_180
			, SUM(CASE WHEN late_days BETWEEN 181 AND 365 THEN olb ELSE 0 END) par_181_365
			, SUM(CASE WHEN late_days BETWEEN 181 AND 365 THEN 1 ELSE 0 END) clients_181_365
			, SUM(CASE WHEN late_days BETWEEN 181 AND 365 AND 'I' = client_type_code THEN 1 ELSE 0 END) contracts_181_365
			, SUM(CASE WHEN late_days > 365 THEN olb ELSE 0 END) par_365
			, SUM(CASE WHEN late_days > 365 THEN 1 ELSE 0 END) clients_365
			, SUM(CASE WHEN late_days > 365 AND 'I' = client_type_code THEN 1 ELSE 0 END) contracts_365
		FROM @active_clients ac
		LEFT JOIN dbo.EconomicActivities doa ON doa.id = ac.activity_id
		GROUP BY ac.activity_id, doa.NAME
		
		UNION ALL
		
		SELECT 'branch' break_down_type
			, b.name break_down
			, SUM(olb) olb
			, SUM(CASE WHEN late_days > 0 THEN olb ELSE 0 END) par
			, SUM(CASE WHEN late_days > 0 THEN 1 ELSE 0 END) clients
			, COUNT(DISTINCT ac.id) all_clients
			, SUM(CASE WHEN late_days > 0 AND 1 = num THEN 1 ELSE 0 END) contracts
			, SUM(CASE WHEN 'I' = client_type_code THEN 1 ELSE 0 END) all_contracts
			, SUM(CASE WHEN late_days > 30 THEN olb ELSE 0 END) par_30
			, SUM(CASE WHEN late_days > 30 THEN 1 ELSE 0 END) clients_30
			, SUM(CASE WHEN late_days > 30 AND 'I' = client_type_code THEN 1 ELSE 0 END) contracts_30
			, SUM(CASE WHEN late_days BETWEEN 1 AND 30 THEN olb ELSE 0 END) par_1_30
			, SUM(CASE WHEN late_days BETWEEN 1 AND 30 THEN 1 ELSE 0 END) clients_1_30
			, SUM(CASE WHEN late_days BETWEEN 1 AND 30 AND 'I' = client_type_code THEN 1 ELSE 0 END) contracts_1_30
			, SUM(CASE WHEN late_days BETWEEN 31 AND 60 THEN olb ELSE 0 END) par_31_60
			, SUM(CASE WHEN late_days BETWEEN 31 AND 60 THEN 1 ELSE 0 END) clients_31_60
			, SUM(CASE WHEN late_days BETWEEN 31 AND 60 AND 'I' = client_type_code THEN 1 ELSE 0 END) contracts_31_60
			, SUM(CASE WHEN late_days BETWEEN 61 AND 90 THEN olb ELSE 0 END) par_61_90
			, SUM(CASE WHEN late_days BETWEEN 61 AND 90 THEN 1 ELSE 0 END) clients_61_90
			, SUM(CASE WHEN late_days BETWEEN 61 AND 90 AND 'I' = client_type_code THEN 1 ELSE 0 END) contracts_61_90
			, SUM(CASE WHEN late_days BETWEEN 91 AND 180 THEN olb ELSE 0 END) par_91_180
			, SUM(CASE WHEN late_days BETWEEN 91 AND 180 THEN 1 ELSE 0 END) clients_91_180
			, SUM(CASE WHEN late_days BETWEEN 91 AND 180 AND 'I' = client_type_code THEN 1 ELSE 0 END) contracts_91_180
			, SUM(CASE WHEN late_days BETWEEN 181 AND 365 THEN olb ELSE 0 END) par_181_365
			, SUM(CASE WHEN late_days BETWEEN 181 AND 365 THEN 1 ELSE 0 END) clients_181_365
			, SUM(CASE WHEN late_days BETWEEN 181 AND 365 AND 'I' = client_type_code THEN 1 ELSE 0 END) contracts_181_365
			, SUM(CASE WHEN late_days > 365 THEN olb ELSE 0 END) par_365
			, SUM(CASE WHEN late_days > 365 THEN 1 ELSE 0 END) clients_365
			, SUM(CASE WHEN late_days > 365 AND 'I' = client_type_code THEN 1 ELSE 0 END) contracts_365
		FROM @active_clients ac
		LEFT JOIN dbo.Branches b ON b.id = ac.branch_id
		GROUP BY b.id, b.name
		ORDER BY break_down_type, break_down
END
