CREATE PROCEDURE [dbo].[Rep_ClientsAndShareOfWomen]
	@date DATETIME, @disbursed_in INT, @display_in INT, @branch_id INT
AS
BEGIN
	SELECT ac.olb * dbo.GetXR(packages.currency_id, @display_in, @date) AS olb, 
	dbo.GetDisbursementDate(ac.id) AS disbursement_date, ac.contract_id AS contract_id, 
	dbo.Users.first_name + SPACE(1) + dbo.Users.last_name AS loan_officer, dbo.Users.id AS loanofficer_id,
	dbo.Packages.name AS Product, dbo.packages.id AS product_id, dbo.packages.currency_id AS currency_id, 
	currencies.name AS currency_name, dbo.Districts.name AS District, dbo.[Districts].id AS District_id,
	dbo.Credit.amount * dbo.GetXR(packages.currency_id, @display_in, @date), 
	dbo.Persons.sex, contracts.close_date, 
	CASE WHEN persons.sex = 'F' THEN 
	ac.olb * dbo.GetXR(packages.currency_id, @display_in, @date)
	ELSE 0 
	END AS femaleOLB, 
	CASE WHEN persons.sex = 'F' THEN 1 ELSE 0 END AS NumberFemale	
	FROM Districts 
	INNER JOIN tiers ON tiers.district_id = Districts.id 
	INNER JOIN persons ON persons.id = tiers.id 
	INNER JOIN dbo.ActiveClients(@date, @branch_id) AS ac ON ac.id = tiers.id 
	INNER JOIN contracts ON ac.contract_id = contracts.id
	INNER JOIN credit ON credit.id = contracts.id 
	INNER JOIN packages ON credit.package_id = packages.id
	INNER JOIN currencies ON currencies.id = packages.currency_id
	INNER JOIN users ON users.id = credit.loanofficer_id
    WHERE tiers.branch_id = @branch_id
END
