CREATE PROCEDURE dbo.Rep_CompulsarySavings @date DATETIME, @disbursed_in INT, @display_in INT, @branch_id INT
AS BEGIN
	DECLARE @active_loans TABLE (
		id INT NOT NULL
		, amount MONEY NOT NULL
	)
	INSERT INTO @active_loans
	SELECT id, amount
	FROM dbo.ActiveLoans_MC(@date, @disbursed_in, @display_in, @branch_id)
	
	DECLARE @clients TABLE (
		id INT NOT NULL
		, client_name NVARCHAR(255) NOT NULL
	)
	INSERT INTO @clients
	SELECT id , ISNULL(first_name,'')+' '+ISNULL(last_name,'')+' '+ISNULL(father_name,'') as client_name
	FROM Persons 
	UNION ALL
	SELECT id, name AS client_name
	FROM Groups 
	UNION ALL
	SELECT id, name AS client_name
	FROM Corporates

	
	SELECT cl.client_name
	, ISNULL(u.first_name,'')+' '+ISNULL(u.last_name,'') AS lo_name
	, co.contract_code
	, cr.amount*dbo.GetXR(pkg.currency_id,@display_in,@date) AS loan_amount
	, pkg.name AS lp_code
	, ll.loan_percentage
	, sc.code
	, dbo.getSavingBalance(sc.id,@date)*dbo.GetXR(pkg.currency_id,@display_in,@date) AS saving_balance
	, asa.balance AS saving_balance
	FROM @active_loans al
	INNER JOIN LoansLinkSavingsBook ll on ll.loan_id = al.id
	INNER JOIN SavingContracts sc on sc.id = ll.savings_id
	INNER JOIN ActiveSavingAccounts_MC(@date, @disbursed_in,@display_in, @branch_id) AS asa ON sc.id=asa.contract_id
	INNER JOIN Contracts co on co.id =ll.loan_id
	INNER JOIN Credit cr on cr.id = co.id
	INNER JOIN Users u on u.id = cr.loanofficer_id
	INNER JOIN Packages pkg on pkg.id = cr.package_id
	INNER JOIN Projects pr on pr.id = co.project_id
	INNER JOIN Tiers ti on ti.id = pr.tiers_id
	INNER JOIN @clients cl ON cl.id = ti.id	
	WHERE (pkg.currency_id=@disbursed_in OR @disbursed_in = 0) AND ti.branch_id = @branch_id			
END
