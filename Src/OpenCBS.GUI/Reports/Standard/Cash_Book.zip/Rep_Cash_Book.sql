CREATE PROCEDURE [dbo].[Rep_Cash_Book]
    @startDate DATETIME
    , @endDate DATETIME
    , @user_id INT
    , @branch_id INT
AS 

BEGIN
	SELECT u.last_name + ' ' + u.first_name AS [User]
	,d.disbursement_date AS Event_date
	,'Loan disbursement' as Event_Type
	,-d.amount AS Amount
	,co.contract_code 
	, COALESCE(pe.last_name + ' ' + pe.first_name,gr.name,cp.name) AS Client_Name
	FROM Disbursements(@startDate, @endDate, @user_id, 0, @branch_id) d
	INNER JOIN Contracts co ON co.id = d.contract_id
	INNER JOIN Credit cr ON cr.id = d.contract_id
	INNER JOIN Projects pr ON pr.id = co.project_id
	INNER JOIN Tiers ti ON ti.id = pr.tiers_id
	INNER JOIN Users u ON u.id = cr.loanofficer_id
	LEFT JOIN Persons pe ON pe.id = ti.id
	LEFT JOIN Groups gr ON gr.id = ti.id
	LEFT JOIN Corporates cp ON cp.id = ti.id
	WHERE d.disbursed = 1

	UNION ALL
	
	SELECT  u.last_name + ' ' + u.first_name AS [User]
	, rea.event_date AS Event_date
	, 'Loan repayment' AS Event_Type
	, rea.principal + rea.interest + rea.penalties + rea.commissions AS Amount
	,co.contract_code AS ContractCode
	,COALESCE(p.last_name + ' ' + p.first_name,g.name,corp.name) AS Client_Name
	FROM RepaymentsAll(@startDate, @endDate, 0, 0, @branch_id) rea
	INNER JOIN Credit cr ON cr.id = rea.contract_id
	INNER JOIN Contracts co ON co.id = rea.contract_id
	INNER JOIN Users u ON u.id = cr.loanofficer_id
	INNER JOIN Projects pr ON pr.id = co.project_id
	INNER JOIN Tiers ti ON ti.id = pr.tiers_id
	LEFT JOIN Persons AS p ON p.id = ti.id
	LEFT JOIN Groups AS g ON g.id = ti.id
	LEFT JOIN Corporates AS corp ON corp.id = ti.id
	
	UNION ALL
	
	SELECT u.last_name + ' ' + u.first_name AS [User]
	, se.creation_date AS Event_date
	, CASE 
	      WHEN se.code = 'SVIE' THEN 'Savings: initial deposit'
	      WHEN se.code = 'SVDE' THEN 'Savings: deposit'
	      WHEN se.code = 'SVWE' THEN 'Savings: withdrawal'
	      WHEN se.code = 'SODE' THEN 'Special Debit Operation'
	      WHEN se.code = 'SOCE' THEN 'Special Credit Operation'
	  END AS Event_Type
	, CASE
	    WHEN se.code = 'SVIE' THEN ([amount]+ISNULL([fees], 0))
		WHEN se.code = 'SVDE' THEN ([amount]+ISNULL([fees], 0))
		WHEN se.code = 'SVWE' THEN (-1)*[amount]
		WHEN se.code = 'SODE' THEN (-1)*se.amount
		WHEN se.code = 'SOCE' THEN se.amount
	  END AS Amount
	, sc.code AS Contract_Code
	, COALESCE(p.last_name + ' ' + p.first_name,g.name, corp.name) AS Client_Name
	FROM SavingEvents AS se 
	INNER JOIN Users AS u ON u.id = se.user_id 
	INNER JOIN SavingContracts AS sc ON sc.id = se.contract_id
	INNER JOIN Tiers AS t ON t.id = sc.tiers_id 
	LEFT JOIN Persons AS p ON p.id = t.id
	LEFT JOIN Groups AS g ON g.id = t.id
	LEFT JOIN Corporates AS corp ON corp.id = t.id
	WHERE 
	(se.savings_method<>20 OR se.savings_method IS NULL)
	AND
	(se.deleted = 0
	AND se.code IN ('SVIE', 'SVDE', 'SVWE','SODE','SOCE')
	AND se.creation_date BETWEEN @startDate AND DATEADD(dd,1,@endDate))
	
	ORDER BY Event_date
END
