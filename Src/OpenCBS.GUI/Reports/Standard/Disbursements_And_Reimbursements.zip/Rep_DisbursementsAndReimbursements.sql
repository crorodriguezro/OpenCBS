CREATE PROCEDURE Rep_DisbursementsAndReimbursements
	@beginDate datetime
	, @endDate datetime
	, @disbursed_in int
	, @display_in int
	, @user_id INT
	, @subordinate_id INT
	, @branch_id INT
AS
BEGIN

    -- The declarations and assignments below look totally retarded
    -- but they are vital as they speed things up by leaps and bounds
    -- Read more about this here:
    -- http://www.eggheadcafe.com/tutorials/aspnet/353cb16c-3cde-44dd-a264-750c1ce4e423/sql-server-query-analyzer-runs-fast--stored-procedure-runs-slow.aspx
    -- or here:
    -- http://elegantcode.com/2008/05/17/sql-parameter-sniffing-and-what-to-do-about-it/
    -- or just google for "ms sql parameter sniffing"
	DECLARE @from DATETIME
	DECLARE @to DATETIME
	DECLARE @_disbursed_in INT
	DECLARE @_display_in INT
	
	SET @from = @beginDate
	SET @to = @endDate
	SET @_disbursed_in = @disbursed_in
	SET @_display_in = @display_in

	SELECT contract_id
	, current_disbursement
	, planned_disbursement
	, planned_principal + late_principal_from AS planned_repayment_principal
	, planned_interest + late_interest_from AS planned_repayment_interests
	, paid_principal AS current_repayment_principal
	, paid_interest AS current_repayment_interests
	, late_principal_to AS overdue_principal
	, late_interest_to AS overdue_interests
	, CASE 
		WHEN paid_principal - (planned_principal + late_principal_from) + late_principal_to < 0 THEN 0
		ELSE paid_principal - (planned_principal + late_principal_from) + late_principal_to
	END prepaid_principal
	, CASE
		WHEN paid_interest - (planned_interest + late_interest_from) + late_interest_to < 0 THEN 0
		ElSE paid_interest - (planned_interest + late_interest_from) + late_interest_to
	END prepaid_interests
	, d.name AS district_name
	, p.name AS product_name
	, u.first_name + ' ' + u.last_name AS USER_NAME
	, b.code AS branch_name
	FROM (
		SELECT contract_id
		, SUM(current_disbursement) AS current_disbursement
		, SUM(planned_disbursement) AS planned_disbursement
		, SUM(planned_principal) AS planned_principal
		, SUM(planned_interest) AS planned_interest
		, SUM(late_principal_from) AS late_principal_from
		, SUM(late_interest_from) AS late_interest_from
		, SUM(paid_principal) AS paid_principal
		, SUM(paid_interest) AS paid_interest
		, SUM(late_principal_to) AS late_principal_to
		, SUM(late_interest_to) AS late_interest_to
		FROM (
			SELECT contract_id
			, CASE WHEN 1 = disbursed THEN amount ELSE 0 END AS current_disbursement
			, amount AS planned_disbursement
			, 0 AS planned_principal
			, 0 AS planned_interest
			, 0 AS late_principal_from
			, 0 AS late_interest_from
			, 0 AS paid_principal
			, 0 AS paid_interest
			, 0 AS late_principal_to
			, 0 AS late_interest_to
			FROM dbo.Disbursements_MC(@from, @to, @_disbursed_in, @_display_in, @user_id, @subordinate_id, @branch_id)
			
			UNION ALL
			
			SELECT contract_id
			, 0 AS current_disbursement
			, 0 AS planned_disbursement
			, SUM(principal - prepaid_principal) AS planned_principal
			, SUM(interest - prepaid_interest) AS planned_interest
			, 0 AS late_principal_from
			, 0 AS late_interest_from
			, 0 AS paid_principal
			, 0 AS paid_interest
			, 0 AS late_principal_to
			, 0 AS late_interest_to
			FROM dbo.ExpectedInstallments_MC(@from, @to, @_disbursed_in, @_display_in, @user_id, @subordinate_id, @branch_id)
			GROUP BY contract_id

			UNION ALL

			SELECT contract_id
			, 0 AS current_disbursement
			, 0 AS planned_disbursement
			, 0 AS planned_principal
			, 0 AS planned_interest
			, principal AS late_principal_from
			, interest AS late_interest_from
			, 0 AS paid_principal
			, 0 AS paid_interest
			, 0 AS late_principal_to
			, 0 AS late_interest_to
			FROM dbo.LateAmounts_MC(@from, @_disbursed_in, @_display_in, @user_id, @subordinate_id, @branch_id)
			
			UNION ALL
			
			SELECT contract_id
			, 0 AS current_disbursement
			, 0 AS planned_disbursement
			, 0 AS planned_principal
			, 0 AS planned_interest
			, 0 AS late_principal_from
			, 0 AS late_interest_from
			, SUM(principal) AS paid_principal
			, SUM(interest) AS paid_interest
			, 0 AS late_principal_to
			, 0 AS late_interest_to
			FROM dbo.Repayments_MC(@from, @to, @_disbursed_in, @_display_in, @user_id, @subordinate_id, @branch_id)
			WHERE written_off = 0
			GROUP BY contract_id
			
			UNION ALL
			
			SELECT contract_id
			, 0 AS current_disbursement
			, 0 AS planned_disbursement
			, 0 AS planned_principal
			, 0 AS planned_interest
			, 0 AS late_principal_from
			, 0 AS late_interest_from
			, 0 AS paid_principal
			, 0 AS paid_interest
			, principal AS late_principal_to
			, interest AS late_interest_to
			FROM dbo.LateAmounts_MC(@to, @_disbursed_in, @_display_in, @user_id, @subordinate_id, @branch_id)
		) AS t
		GROUP BY contract_id
	) AS rs
	INNER JOIN dbo.Contracts AS c ON c.id = rs.contract_id
	INNER JOIN dbo.Credit AS cr ON cr.id = c.id
	LEFT JOIN dbo.Projects AS j ON j.id = c.project_id
	LEFT JOIN dbo.Tiers AS t ON t.id = j.tiers_id
	LEFT JOIN dbo.Districts AS d ON d.id = t.district_id
	LEFT JOIN dbo.Users AS u ON u.id = cr.loanofficer_id
	LEFT JOIN dbo.Packages AS p ON p.id = cr.package_id
	LEFT JOIN dbo.Branches AS b ON b.id = t.branch_id
END
