CREATE PROCEDURE dbo.Rep_Active_Savings_By_Activity 
@pDate DATETIME, 
@disbursed_in INT, 
@display_in INT
, @branch_id INT
AS BEGIN

 SELECT 
   CASE sp.product_type
			WHEN 'B' THEN 'Savings Book'
			WHEN 'T' THEN 'Savings Deposit'
			WHEN 'C' THEN 'Compulsory Savings'
		END AS product_type, 
   ea.name AS activity,
   COUNT(*) AS contracts,
   SUM(asl.balance) AS balance
 FROM ActiveSavingAccounts_MC(@pDate,@disbursed_in,@display_in, @branch_id) asl
 INNER JOIN SavingContracts sc ON sc.id = asl.contract_id
 INNER JOIN SavingProducts sp ON sp.id = sc.product_id
 INNER JOIN (
			SELECT id,activity_id
			FROM Persons
			UNION ALL
			SELECT id,activity_id
			FROM Corporates
			) cl ON cl.id = asl.client_id
  INNER JOIN EconomicActivities ea ON ea.id = cl.activity_id
  GROUP BY sp.product_type,ea.name
  ORDER BY sp.product_type,ea.name 
END
