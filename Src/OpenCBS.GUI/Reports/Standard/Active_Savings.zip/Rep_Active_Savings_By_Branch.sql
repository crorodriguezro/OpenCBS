CREATE PROCEDURE Rep_Active_Savings_By_Branch
@pDate DATETIME, 
@disbursed_in INT, 
@display_in INT
, @branch_id INT
AS
BEGIN 
  
 SELECT 
   CASE sp.product_type
			WHEN 'B' THEN 'Savings Book'
			WHEN 'T' THEN 'Savings Deposit'
			WHEN 'C' THEN 'Compulsory Savings'
		END AS product_type, 
   br.code AS branch_name,
   COUNT(*) AS contracts,
   SUM(asl.balance) AS balance
 FROM ActiveSavingAccounts_MC(@pDate,@disbursed_in,@display_in, @branch_id) asl
 INNER JOIN SavingContracts sc ON sc.id = asl.contract_id
 INNER JOIN SavingProducts sp ON sp.id = sc.product_id
 INNER JOIN Tiers ti ON ti.id = asl.client_id
 INNER JOIN dbo.Branches br ON br.id = ti.branch_id
 GROUP BY sp.product_type,br.code
 ORDER BY sp.product_type,br.code
 
END
