CREATE PROCEDURE dbo.Rep_Reassigned_Loans
	@from DATETIME, @to DATETIME, @disbursed_in INT, @display_in INT, @branch_id INT
AS BEGIN
SELECT 
	Cont.contract_code AS [contract_code],
	COALESCE(Corp.Name, Gr.name, ISNULL(Pers.first_name, '') + SPACE(1) + ISNULL(Pers.last_name, '')) AS [client_name],
	Cr.amount * dbo.GetXR(Pack.currency_id, @display_in, @to) AS [loan_amount],
	CAST(COALESCE(AcLo.olb, dbo.GetOLB(Cont.Id, @to)) * dbo.GetXR(Pack.currency_id, @display_in, @to) AS MONEY) AS [olb],
	UsFr.first_name + SPACE(1) + UsFr.last_name AS [loan_officer_fr],
	UsTo.first_name + SPACE(1) + UsTo.last_name AS [loan_officer_to],
	Cont.align_disbursed_date AS [dis_date],
	CoAsHis.DateChanged AS [reas_date]
	FROM
	(
		SELECT t.id, t.contract_id, t.loanofficerFrom_id, t.loanofficerTo_id, t.DateChanged 
		FROM dbo.ContractAssignHistory t WITH (NOLOCK) WHERE t.DateChanged = 
		(
			SELECT MAX(DateChanged) FROM dbo.ContractAssignHistory WHERE contract_id = t.contract_id
		)
	) AS CoAsHis
	INNER JOIN dbo.Contracts AS Cont ON CoAsHis.contract_id = Cont.id
	INNER JOIN dbo.Credit AS Cr ON Cr.id = Cont.id
	LEFT JOIN (
				SELECT * 
				FROM dbo.ActiveLoans(@to, @branch_id)
			   ) AS AcLo ON AcLo.id = Cont.id
	INNER JOIN dbo.Packages AS Pack ON Cr.package_id = Pack.id
	INNER JOIN dbo.Users AS UsFr ON CoAsHis.loanofficerFrom_id = UsFr.id
	INNER JOIN dbo.Users AS UsTo ON CoAsHis.loanofficerTo_id = UsTo.id
	
	LEFT JOIN dbo.Projects AS Pr ON Cont.project_id = Pr.id
	LEFT JOIN dbo.Corporates AS Corp ON Corp.id=Pr.tiers_id
	LEFT JOIN dbo.Groups AS Gr ON Gr.id = Pr.tiers_id
	LEFT JOIN dbo.Persons AS Pers ON Pers.id = Pr.tiers_id
	--WHERE CAST(FLOOR(CAST(CoAsHis.DateChanged AS FLOAT)) AS DATETIME) BETWEEN @from AND @to 
	WHERE CAST(CONVERT(nvarchar, CoAsHis.DateChanged, 111) AS DATETIME) BETWEEN @from AND @to 
	AND (Pack.currency_id = @disbursed_in OR 0 = @disbursed_in)
END
