CREATE PROCEDURE dbo.Rep_Delinquent_Loans
	@date DATETIME
	, @disbursed_in INT
	, @display_in INT
	, @user_id INT
	, @subordinate_id INT
	, @branch_id INT
AS BEGIN
   DECLARE @event_dates TABLE (
			    [date] DATE,
			    contract_id INT,
				event_id INT ,
				principal DECIMAL(18,4),
				interest  DECIMAL(18,4))	
					    
			    INSERT @event_dates 
			    SELECT  event_date, contract_id,event_id, principal,interest   FROM  dbo.Repayments(CAST('01-01-2014' as DATE)  , @date, @user_id,@subordinate_id,@branch_id)  
    
			    
if (object_id('tempdb..#RepaymentEvents') is null)
    begin
        create table #RepaymentEvents
        (
            contract_id int
		    , num INT
		    , installment_number INT
		    , interest MONEY
		    , principal MONEY
		    , penalty MONEY
		    , event_date DATETIME
		    , total MONEY
		    , rt_interest MONEY
		    , rt_principal MONEY
		    , rt_total MONEY
        )
        CREATE INDEX IX_Contract_id ON #RepaymentEvents (contract_id) -- speed things up
    end

    truncate table #RepaymentEvents
    INSERT INTO #RepaymentEvents
    SELECT re1.contract_id, re1.num, re1.installment_number, re1.interests, re1.principal, re1.penalties, re1.event_date, re1.total 
    , SUM(re2.interests) AS rt_interest
    , SUM(re2.principal) AS rt_principal
    , SUM(re2.total) AS rt_total
    FROM
    (
	    SELECT ce.contract_id, re.interests, re.principal, re.penalties, ce.event_date
	    , ROW_NUMBER() OVER (partition by contract_id ORDER BY event_date, re.id) AS num
	    , re.interests + re.principal AS total
	    , re.installment_number
	    FROM dbo.RepaymentEvents AS re
	    LEFT JOIN dbo.ContractEvents AS ce ON re.id = ce.id
	    WHERE is_deleted = 0 AND event_date <= @date
    ) AS re1
    LEFT JOIN
    (
	    SELECT ce.contract_id, re.interests, re.principal, re.penalties, ce.event_date
	    , ROW_NUMBER() OVER (partition by contract_id ORDER BY event_date, re.id) AS num
	    , re.interests + re.principal AS total
	    FROM dbo.RepaymentEvents AS re
	    LEFT JOIN dbo.ContractEvents AS ce ON re.id = ce.id
	    WHERE is_deleted = 0 AND event_date <= @date
    ) AS re2 ON re1.contract_id = re2.contract_id and  re2.num <= re1.num
    GROUP BY re1.contract_id, re1.num, re1.installment_number, re1.event_date, re1.principal,re1.penalties, re1.interests, re1.total

	-- Create temporary table for storing installment data
	IF OBJECT_ID('tempdb..#installments') IS NULL
	BEGIN
		CREATE TABLE #installments
		(
			contract_id INT
			, number INT
			, expected_date DATETIME
			, principal MONEY
			, interest MONEY
			, paid_principal MONEY
			, paid_interest MONEY
			, paid_date DATETIME
		)
		CREATE INDEX IX_Contract_id ON #installments (contract_id) -- speed things up
	END
	TRUNCATE TABLE #installments
	INSERT INTO #installments SELECT * FROM dbo.InstallmentSnapshot(@date)

	-- Create temporary table for storing penalties
	IF OBJECT_ID('tempdb..#penalties') IS NULL
	BEGIN
		CREATE TABLE #penalties
		(
			contract_id INT
			, penalty MONEY
		)
	END
	TRUNCATE TABLE #penalties

	DECLARE @active_loans TABLE
	(
		id INT NOT NULL
		, late_days INT NOT NULL
		, olb MONEY NOT NULL
	)
	INSERT INTO @active_loans
	SELECT id, late_days, olb
	FROM dbo.ActiveLoans(@date, @branch_id)

	-- Calculate penalties
	DECLARE @contract_id INT
	DECLARE cur CURSOR FOR 
	SELECT al.id FROM @active_loans al
	--SELECT al.id FROM dbo.ActiveLoans(@date, @branch_id) AS al

	LEFT JOIN dbo.Credit AS cr ON cr.id = al.id
	LEFT JOIN dbo.Packages AS pkg ON pkg.id = cr.package_id
	WHERE pkg.currency_id = @disbursed_in OR 0 = @disbursed_in
	OPEN cur
	FETCH NEXT FROM	cur
	INTO @contract_id
	WHILE 0 = @@FETCH_STATUS
	BEGIN
		EXEC dbo.CalculateLatePenalty @contract_id, @date
		FETCH NEXT FROM cur
		INTO @contract_id
	END
	CLOSE cur
	DEALLOCATE cur
	
 
	-- Fetch data
	SELECT   
	temp.* , 
	  ISNULL(( SELECT 
	       CASE WHEN  (SELECT TOP 1 res.event_date FROM #RepaymentEvents res WHERE res.contract_id = temp.id ORDER BY res.event_date)=@date
	    THEN    
	      SUM(inn.principal) 
	    ELSE  
	      SUM(inn.principal) -SUM(inn.paid_principal)
	    END
	     FROM #Installments inn WHERE inn.contract_id = temp.id AND DATEADD(DAY, -1,@date)>inn.expected_date 
	    ),0)
	     AS late_principal
	, due_interest - paid_interest AS late_interest
	   
   , ISNULL(( Select  TOP 1 DATEDIFF(DAY, il.expected_date,@date) from #installments il Where il.contract_id = temp.id AND il.expected_date <  @date AND il.paid_principal >0 ORDER BY il.expected_date desc ),0) AS count_days
	, 
	   ISNULL((SELECT  SUM(ree.principal)  FROM #RepaymentEvents ree WHERE contract_id = temp.id
	   AND ree.event_date = @date ),0) AS pay_amount
	 , 
	 ISNULL(((SELECT   
	         
	         TOP 1 CASE
	          WHEN   inn.paid_date = @date THEN  inn.principal - inn.paid_principal
	          WHEN  DATEDIFF( DAY, inn.expected_date ,@date) = 1 THEN inn.principal -inn.paid_principal
	          ELSE 0
	          END
	      FROM #Installments inn WHERE inn.contract_id = temp.id AND DATEADD(DAY, 1,@date)>inn.expected_date-- AND inn.paid_principal > 0 
	      ORDER BY inn.expected_date DESC)   
	 ),0)  AS amount
	FROM
					(
						SELECT al.id
						,c.contract_code
						,ISNULL(corp.name,ISNULL(g.name, prsn.first_name)) as client_first_name
						, ISNULL(corp.name,ISNULL(g.name,prsn.last_name)) AS client_last_name
						, d.name AS district_name
					 	, pkg.code AS product_code
						 , pkg.name AS product_name
					 	, u.first_name + ' ' + u.last_name AS loan_officer_name
						 , dbo.GetDisbursementDate(al.id) AS [start_date]
					  	, (SELECT MAX(expected_date) FROM #installments WHERE contract_id = c.id) end_date
						, al.late_days  
						, CAST(al.olb * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS olb
						, CAST(cr.amount * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS amount
						, CAST(p.penalty * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS penalty
						, CAST(ISNULL(i.paid_principal, 0) * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS paid_principal
						, CAST(ISNULL(i.paid_interest, 0) * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS paid_interest
						, CAST(ISNULL(i.due_principal, 0) * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS due_principal
						, CAST(ISNULL(i.due_interest, 0) * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS due_interest
						FROM @active_loans al
						LEFT JOIN #penalties AS p ON al.id = p.contract_id
						LEFT JOIN dbo.Contracts AS c ON c.id = al.id
						LEFT JOIN dbo.Credit AS cr ON cr.id = c.id
						LEFT JOIN dbo.Projects AS j ON j.id = c.project_id
						LEFT JOIN dbo.Tiers AS t ON t.id = j.tiers_id
						LEFT JOIN dbo.Persons AS prsn ON prsn.id = t.id
						LEFT JOIN dbo.Corporates AS corp ON corp.id = t.id
						LEFT JOIN dbo.Groups AS g ON g.id = t.id
						LEFT JOIN dbo.Districts AS d ON d.id = t.district_id
						LEFT JOIN dbo.Packages AS pkg ON pkg.id = cr.package_id
						LEFT JOIN dbo.Users AS u ON u.id = cr.loanofficer_id
						LEFT JOIN
						(
							SELECT i.contract_id
								, SUM(CASE WHEN i.expected_date = @date THEN 0 ELSE  i.principal END) AS due_principal
								, SUM(CASE WHEN i.expected_date = @date THEN 0 ELSE  i.interest END) AS due_interest
								, SUM(i.paid_principal) paid_principal
								, SUM(i.paid_interest) paid_interest
							FROM #installments AS i
							WHERE i.expected_date <= @date
							GROUP BY i.contract_id
						) AS i ON i.contract_id = al.id
						WHERE p.penalty >= 0 AND al.late_days > 0 	  
						AND ((0 = @branch_id AND t.branch_id IN (SELECT branch_id FROM dbo.UsersBranches WHERE user_id = @user_id))
						OR t.branch_id = @branch_id)
						AND (@subordinate_id = 0 and cr.loanofficer_id in
						(	SELECT @user_id
							UNION ALL
							SELECT subordinate_id
							FROM dbo.UsersSubordinates
							WHERE user_id = @user_id) OR cr.loanofficer_id = @subordinate_id)
						  AND (pkg.currency_id = @disbursed_in OR 0 = @disbursed_in)
						  AND NOT(paid_principal >= due_principal AND paid_interest >= due_interest)
					) AS temp   
	ORDER BY 
	 loan_officer_name, product_name, late_days DESC 
	
END
