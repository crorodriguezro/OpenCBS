CREATE PROCEDURE dbo.Rep_Delinquent_Loans 
	@date DATETIME
	, @disbursed_in INT
	, @display_in INT
	, @user_id INT
	, @subordinate_id INT
	, @branch_id INT
AS BEGIN
	-- Create temporary table for storing installment data
	IF OBJECT_ID('tempdb..#installments') IS NULL
	BEGIN
		CREATE TABLE #installments
		(
			contract_id INT
			, number INT
			, expected_date DATETIME
			, principal MONEY
			, interest MONEY
			, paid_principal MONEY
			, paid_interest MONEY
			, paid_date DATETIME
		)
		CREATE INDEX IX_Contract_id ON #installments (contract_id) -- speed things up
	END
	TRUNCATE TABLE #installments
	INSERT INTO #installments SELECT * FROM dbo.InstallmentSnapshot(@date)

	-- Create temporary table for storing penalties
	IF OBJECT_ID('tempdb..#penalties') IS NULL
	BEGIN
		CREATE TABLE #penalties
		(
			contract_id INT
			, penalty MONEY
		)
	END
	TRUNCATE TABLE #penalties

	DECLARE @active_loans TABLE
	(
		id INT NOT NULL
		, late_days INT NOT NULL
		, olb MONEY NOT NULL
	)
	INSERT INTO @active_loans
	SELECT id, late_days, olb
	FROM dbo.ActiveLoans(@date, @branch_id)

	-- Calculate penalties
	DECLARE @contract_id INT
	DECLARE cur CURSOR FOR 
	SELECT al.id FROM @active_loans al
	--SELECT al.id FROM dbo.ActiveLoans(@date, @branch_id) AS al

	LEFT JOIN dbo.Credit AS cr ON cr.id = al.id
	LEFT JOIN dbo.Packages AS pkg ON pkg.id = cr.package_id
	WHERE pkg.currency_id = @disbursed_in OR 0 = @disbursed_in
	OPEN cur
	FETCH NEXT FROM	cur
	INTO @contract_id
	WHILE 0 = @@FETCH_STATUS
	BEGIN
		EXEC dbo.CalculateLatePenalty @contract_id, @date
		FETCH NEXT FROM cur
		INTO @contract_id
	END
	CLOSE cur
	DEALLOCATE cur

	-- Fetch data
	SELECT *
	, CASE WHEN paid_principal > due_principal THEN 0 ELSE due_principal - paid_principal END AS late_principal
	, CASE WHEN paid_interest > due_interest THEN 0 ELSE due_interest - paid_interest END AS late_interest
	FROM
	(
		SELECT al.id, c.contract_code
		,ISNULL(corp.name,ISNULL(g.name, prsn.first_name)) as client_first_name
        , ISNULL(corp.name,ISNULL(g.name,prsn.last_name)) AS client_last_name
		, d.name AS district_name
		, pkg.code AS product_code
        , pkg.name AS product_name
		, u.first_name + ' ' + u.last_name AS loan_officer_name
		, dbo.GetDisbursementDate(al.id) AS [start_date]
        , (SELECT MAX(expected_date) FROM #installments WHERE contract_id = c.id) end_date
		, al.late_days
		, CAST(al.olb * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS olb
		, CAST(cr.amount * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS amount
		, CAST(p.penalty * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS penalty
		, CAST(ISNULL(i.paid_principal, 0) * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS paid_principal
		, CAST(ISNULL(i.paid_interest, 0) * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS paid_interest
		, CAST(ISNULL(i.due_principal, 0) * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS due_principal
		, CAST(ISNULL(i.due_interest, 0) * dbo.GetXR(pkg.currency_id, @display_in, @date) AS MONEY) AS due_interest
		FROM @active_loans al
		LEFT JOIN #penalties AS p ON al.id = p.contract_id
		LEFT JOIN dbo.Contracts AS c ON c.id = al.id
		LEFT JOIN dbo.Credit AS cr ON cr.id = c.id
		LEFT JOIN dbo.Projects AS j ON j.id = c.project_id
		LEFT JOIN dbo.Tiers AS t ON t.id = j.tiers_id
		LEFT JOIN dbo.Persons AS prsn ON prsn.id = t.id
		LEFT JOIN dbo.Corporates AS corp ON corp.id = t.id
		LEFT JOIN dbo.Groups AS g ON g.id = t.id
		LEFT JOIN dbo.Districts AS d ON d.id = t.district_id
		LEFT JOIN dbo.Packages AS pkg ON pkg.id = cr.package_id
		LEFT JOIN dbo.Users AS u ON u.id = cr.loanofficer_id
		LEFT JOIN
		(
			SELECT i.contract_id
                , SUM(CASE WHEN i.expected_date = @date THEN 0 ELSE  i.principal END) AS due_principal
                , SUM(CASE WHEN i.expected_date = @date THEN 0 ELSE  i.interest END) AS due_interest
				, SUM(i.paid_principal) paid_principal
				, SUM(i.paid_interest) paid_interest
			FROM #installments AS i
			WHERE i.expected_date <= @date
			GROUP BY i.contract_id
		) AS i ON i.contract_id = al.id
		WHERE p.penalty >= 0 AND al.late_days > 0 	  
		AND ((0 = @branch_id AND t.branch_id IN (SELECT branch_id FROM dbo.UsersBranches WHERE user_id = @user_id))
		OR t.branch_id = @branch_id)
		AND (@subordinate_id = 0 and cr.loanofficer_id in
		(	SELECT @user_id
			UNION ALL
			SELECT subordinate_id
			FROM dbo.UsersSubordinates
			WHERE user_id = @user_id) OR cr.loanofficer_id = @subordinate_id)
		  AND (pkg.currency_id = @disbursed_in OR 0 = @disbursed_in)
		  AND NOT(paid_principal >= due_principal AND paid_interest >= due_interest)
	) AS temp
	ORDER BY loan_officer_name, product_name, late_days DESC
END
